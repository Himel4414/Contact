
"""
High Use
"""
#%%
import geopandas as gpd
import os
import pandas as pd
#%%
# Path to the folder containing your shapefiles
folder_path = r"C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit"
# List all shapefiles in the folder
shapefiles = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith('.shp')]
# Combine all shapefiles into a single GeoDataFrame
all_gdfs = [gpd.read_file(shp) for shp in shapefiles]
full_gdf = gpd.GeoDataFrame(pd.concat(all_gdfs, ignore_index=True))
#%%
# Group by geometry and sum the 'nsv_420' and 'mnlv_420' columns
grouped_gdf = full_gdf.groupby('geometry').agg({'nsv_420': 'sum', 'mnlv_420': 'sum'}).reset_index()
print(grouped_gdf)
#%%
shp = gpd.GeoDataFrame(grouped_gdf, geometry = "geometry")
print(shp)
#%%
# Save the stacked GeoDataFrame to a new shapefile
output_shapefile = r"C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/vis_stack.shp"
shp.to_file(output_shapefile)
#%%
vis = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/vis_stack.shp")
visit = vis[vis['nsv_420'] != 0].copy()
print(visit)
#%%
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Generate frequency table
frequency_table = visit['nsv_420'].value_counts().reset_index()
frequency_table.columns = ['Value', 'Frequency']

# Sort the table by value for better readability
frequency_table = frequency_table.sort_values(by='Value').reset_index(drop=True)
pd.reset_option('display.max_rows')

# Display the full frequency table
print(frequency_table)
frequency_table.to_csv('frequency_table.csv', index=False)
#%%
import pandas as pd
# Assuming 'visit' is your DataFrame
# visit = pd.read_csv('your_data.csv')  # Load your data here

# Calculate specific percentiles
percentiles = [0.30, 0.50, 0.75]
percentile_values = visit['nsv_420'].quantile(percentiles)
print(percentile_values)

#2,5,16
#%%
final = visit[visit['nsv_420'] > 16]
output_shapefile = r"C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use.shp"
final.to_file(output_shapefile)
#%%
final = visit[visit['nsv_420'] > 49]
output_shapefile = r"C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use_u.shp"
final.to_file(output_shapefile)
#%%
final = visit[visit['nsv_420'] > 5]
output_shapefile = r"C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use_l.shp"
final.to_file(output_shapefile)
#%%