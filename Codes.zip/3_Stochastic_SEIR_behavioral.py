#%%1
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import numpy as np
import panel as pn
from scipy.stats import beta
#%%2
indir1_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_7_pd.csv")
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_30_pd.csv")
#%%3
indir1_df = indir1_df.iloc[:,[0,1,3]]
indir2_df = indir2_df.iloc[:,[0,1,3]]
indir1_df.columns = ["id1", "id2", "weight"]
indir2_df.columns = ["id1", "id2", "weight"]
indir1_df['id1'] = indir1_df['id1'].astype(str)
indir1_df['id2'] = indir1_df['id2'].astype(str)
indir2_df['id1'] = indir2_df['id1'].astype(str)
indir2_df['id2'] = indir2_df['id2'].astype(str)
#%%4
g_indirect7 = nx.from_pandas_edgelist(indir1_df, source='id1', target='id2', edge_attr='weight', create_using=nx.DiGraph())
g_indirect30 = nx.from_pandas_edgelist(indir2_df, source='id1', target='id2', edge_attr='weight', create_using=nx.DiGraph())
#%%5
# Calculate in-degree centrality (number of incoming edges)
in_degree_centrality = dict(g_indirect7.in_degree())

# Calculate out-degree centrality (number of outgoing edges)
out_degree_centrality = dict(g_indirect7.out_degree())

# Convert results into a DataFrame for better readability
centrality_df = pd.DataFrame({
    'ID': list(in_degree_centrality.keys()),
    'In-Degree Centrality': list(in_degree_centrality.values()),
    'Out-Degree Centrality': list(out_degree_centrality.values())
})


print(centrality_df)   # 626 is more connected, 464 is less connected

#%%
# Preprocess the weights in the graph
def preprocess_weights(graph, scaling_factor=1.0):
    adj_matrix = nx.to_numpy_array(graph, weight="weight")

    # Normalize weights to [0, 1]
    max_weight = np.max(adj_matrix)
    if max_weight > 0:
        adj_matrix /= max_weight

    # Apply scaling factor
    adj_matrix *= scaling_factor
    return adj_matrix
#%%
# Function to sample a value from a given range (for stochastic parameters)
def sample_uniform(param_range):
    return np.random.uniform(param_range[0], param_range[1])
#%%
def stochastic_seir_env_model_with_env(
    graph, days, initial_infected,
    beta_range, gamma_range, sigma_range,
    decay_rate, shedding_range, acquisition_range,
    scaling_factor=1.0, max_infectious_days=7, iterations=1000
):
    """
    Simulates a stochastic SEIR model with an explicit environmental compartment.
    
    The compartments for each node are now:
        0: Susceptible (S)
        1: Exposed (E)
        2: Infected (I)
        3: Recovered (R)
        4: Environment (Env)
    
    The force of infection has two parts:
        - Network infection: beta_rate * (adjacency force from infected neighbors)
        - Environmental infection: acquisition_rate * (local environmental contamination)
    
    The environmental compartment is updated as:
        Env[t] = Env[t-1]*exp(-decay_rate) + shedding_rate * I[t-1]
    
    Parameters:
      - graph: Directed NetworkX graph (nodes represent patches or individuals)
      - days: Simulation duration (number of days)
      - initial_infected: List of node indices that start with a small exposure
      - beta_range: Tuple for network transmission rate (stochastic)
      - gamma_range: Tuple for recovery rate (stochastic)
      - sigma_range: Tuple for progression rate from E to I (stochastic)
      - decay_rate: Deterministic decay rate for the environmental pathogen
      - shedding_range: Tuple for environmental shedding rate (stochastic)
      - acquisition_range: Tuple for environmental acquisition rate (stochastic)
      - scaling_factor: Factor to scale the edge weights (default=1.0)
      - max_infectious_days: Maximum days an individual can transmit via network
      - iterations: Number of stochastic iterations
      
    Returns:
      - median_values: Array (days x 5) of median totals (over nodes) for each compartment.
      - all_runs: List of arrays from each iteration (each array shape: days x 5)
    """
    n = len(graph.nodes)
    adj_matrix = preprocess_weights(graph, scaling_factor)  # Use your normalization function

    # This list will hold the time series for each stochastic iteration.
    all_runs = []

    # Run the simulation for each iteration
    for iteration in range(iterations):
        # Initialize states: now shape (days, compartments, nodes) with 5 compartments
        states = np.zeros((days, 5, n))
        # Set initial conditions: everyone is susceptible
        states[0, 0, :] = 1.0  
        # For the initially infected nodes, add a small exposure
        for node in initial_infected:
            states[0, 1, node] = 0.01  # Exposed
            states[0, 0, node] -= 0.01 # Adjust susceptible
        # Initialize environment compartment to 0 at t=0 for all nodes
        states[0, 4, :] = 0.0

        # This array tracks, for each node, how many days it has been actively infected
        infectious_days = np.zeros(n)

        for t in range(1, days):
            # Retrieve previous time-step compartments:
            S = states[t-1, 0, :].copy()
            E = states[t-1, 1, :].copy()
            I = states[t-1, 2, :].copy()
            R = states[t-1, 3, :].copy()
            Env = states[t-1, 4, :].copy()  # local environmental contamination

            # Sample the stochastic parameters for this day
            beta_rate = sample_uniform(beta_range)
            gamma_rate = sample_uniform(gamma_range)
            sigma_rate = sample_uniform(sigma_range)
            shedding_rate = sample_uniform(shedding_range)
            acquisition_rate = sample_uniform(acquisition_range)

            # Calculate the force of infection from the network.
            # (Using the transposed adjacency matrix, as in your original code.)
            network_force = beta_rate * (adj_matrix.T @ I)
            # Calculate environmental force for each node (local effect)
            env_force = acquisition_rate * Env

            # The total force on susceptibles is the sum of network and environmental forces.
            total_force = network_force + env_force

            # Apply a “cap” on network infection for nodes that have been infectious too long.
            # (This mimics that nodes stop contributing to network infection after max_infectious_days.)
            for node in range(n):
                if infectious_days[node] >= max_infectious_days:
                    network_force[node] = 0.0
            # Recompute total force after capping network contribution.
            total_force = network_force + env_force

            # Compute the changes (using a simple Euler-type step):
            dS = - total_force * S
            dE = total_force * S - sigma_rate * E
            dI = sigma_rate * E - gamma_rate * I
            dR = gamma_rate * I
            # Update the environmental compartment:
            # Here we use an exponential decay factor and add shedding from I.
            new_Env = Env * np.exp(-decay_rate) + shedding_rate * I

            # Update the compartments (and ensure values remain non-negative).
            states[t, 0, :] = np.clip(S + dS, 0, 1)
            states[t, 1, :] = np.clip(E + dE, 0, 1)
            states[t, 2, :] = np.clip(I + dI, 0, 1)
            states[t, 3, :] = np.clip(R + dR, 0, 1)
            # For the environment, negative values do not make sense:
            states[t, 4, :] = np.maximum(new_Env, 0)

            # Update the infectious_days counter:
            infectious_days = np.where(I > 0.01, infectious_days + 1, 0)

        # Sum over nodes to get the total (or average) value in each compartment at each day.
        # The resulting array has shape (days, 5)
        all_runs.append(np.sum(states, axis=2))

    median_values = np.median(np.array(all_runs), axis=0)
    return median_values, all_runs

#%% Example: Running the updated model on the 7-day persistence network

# (Re-use g_indirect7 from your earlier code)
graph = g_indirect7  
days = 365
initial_infected = [5]

# Parameter ranges (same as before; these now drive both network and environment components)
beta_range = (0.3, 0.6)        # network transmission rate
gamma_range = (0.14, 0.2)        # recovery rate
sigma_range = (0.2, 0.33)        # progression from E to I
decay_rate = 0.7               # environmental decay rate
shedding_range = (0.3, 0.6)      # shedding rate into environment
acquisition_range = (0.2, 0.5)   # rate at which Env causes infection

scaling_factor = 1
max_infectious_days = 7
iterations = 1000
#%%
median_results, all_runs = stochastic_seir_env_model_with_env(
    graph, days, initial_infected,
    beta_range, gamma_range, sigma_range,
    decay_rate, shedding_range, acquisition_range,
    scaling_factor, max_infectious_days, iterations
)
#%%
# Re-use the sample_uniform function from before
def sample_uniform(param_range):
    """Sample a value uniformly from the given range."""
    return np.random.uniform(param_range[0], param_range[1])

def compute_stochastic_R0_env_only(gamma_range, shedding_range, acquisition_range, decay_rate, iterations=1000):
    """
    Computes the stochastic basic reproduction number (R0) for the environmental 
    indirect transmission only.
    
    The environmental R0 is calculated as:
        R0 = (shedding * acquisition) / (gamma * decay_rate)
    
    Parameters:
      - gamma_range: Tuple for the recovery rate.
      - shedding_range: Tuple for the environmental shedding rate.
      - acquisition_range: Tuple for the environmental acquisition rate.
      - decay_rate: Deterministic decay rate for the environmental compartment.
      - iterations: Number of stochastic samples to generate.
    
    Returns:
      - R0_values: NumPy array of computed R0 values (one per iteration).
      - R0_median: Median value of R0 from the iterations.
    """
    R0_values = []

    for _ in range(iterations):
        # Sample the stochastic parameters
        gamma = sample_uniform(gamma_range)
        shedding = sample_uniform(shedding_range)
        acquisition = sample_uniform(acquisition_range)

        # Compute R0 from the environmental route only
        R0 = (shedding * acquisition) / (gamma * decay_rate)
        R0_values.append(R0)

    R0_values = np.array(R0_values)
    R0_median = np.median(R0_values)
    return R0_values, R0_median

#%% Example usage:

# Define parameter ranges (using your 7-day persistence example values)
gamma_range = (0.14, 0.2)         # Recovery rate
shedding_range = (0.3, 0.6)         # Environmental shedding rate
acquisition_range = (0.2, 0.5)      # Environmental acquisition rate
decay_rate = 0.7                # Environmental decay rate

iterations = 1000  # Number of stochastic runs

# Compute stochastic R0 for environmental transmission only
R0_values, R0_median = compute_stochastic_R0_env_only(gamma_range, shedding_range, acquisition_range, decay_rate, iterations)

# Display the results
print(f"Mean Environmental R0: {np.mean(R0_values):.3f}")
print(f"Standard Deviation of Environmental R0: {np.std(R0_values):.3f}")
#%%
def calculate_time_to_peak(all_runs):
    """
    Calculate the time to peak incidence for each stochastic run.
    
    Parameters:
      - all_runs: List of arrays from your simulation. Each array should be of shape (days, 4)
                  where column 2 corresponds to the Infected (I) compartment.
    
    Returns:
      - mean_time_to_peak: The mean day of peak incidence across runs.
      - std_time_to_peak: The standard deviation of the peak day across runs.
      - time_to_peak_list: A list of the peak day (time index) for each run.
    """
    time_to_peak_list = []
    
    # Loop over each simulation run
    for run in all_runs:
        # Extract the infectious time series (assuming column 2 corresponds to I)
        I_series = run[:, 2]
        # Find the day (index) when I is maximal
        peak_day = np.argmax(I_series)
        time_to_peak_list.append(peak_day)
    
    mean_time_to_peak = np.mean(time_to_peak_list)
    std_time_to_peak = np.std(time_to_peak_list)
    
    return mean_time_to_peak, std_time_to_peak, time_to_peak_list
#%% 
# Calculate time to peak incidence:
mean_peak, std_peak, peak_list = calculate_time_to_peak(all_runs)
print(f"Time to peak incidence: {mean_peak:.2f} ± {std_peak:.2f} days")

#%% Updated Plotting Function (including Environment)

def plot_all_runs_with_median_and_env(all_runs, median_results, days, R0_value, TPI_value):
    """
    Plots all stochastic SEIR runs (with an added environmental compartment) along with the median trajectory.
    The five compartments are: S, E, I, R, and Env.
    
    Parameters:
      - all_runs: List of simulation runs (each: days x 5 array).
      - median_results: Median values over iterations (days x 5).
      - days: Number of simulation days.
      - R0_value: A string summarizing the reproduction number (e.g., "2.48 ± 0.63").
      - TPI_value: A string for total pathogen impact (e.g., "36.20 ± 2.01 days").
    """
    time_steps = np.arange(days)
    all_runs_array = np.array(all_runs)  # shape: (iterations, days, 5)
    
    # Extract compartments across runs:
    S_runs = all_runs_array[:, :, 0]
    E_runs = all_runs_array[:, :, 1]
    I_runs = all_runs_array[:, :, 2]
    R_runs = all_runs_array[:, :, 3]
    Env_runs = all_runs_array[:, :, 4]
    
    # Define colors for each compartment
    colors = {
        "S": "blue", 
        "E": "orange", 
        "I": "red", 
        "R": "green",
        "Env": "purple"
    }
    
    plt.figure(figsize=(12, 8))
    
    # Plot all iterations in light lines, then overplot the median in a darker (or thicker) line.
    for run in S_runs:
        plt.plot(time_steps, run, color=colors["S"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 0], label="Susceptible", color='darkblue', linewidth=2)
    
    for run in E_runs:
        plt.plot(time_steps, run, color=colors["E"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 1], label="Exposed", color='darkorange', linewidth=2)
    
    for run in I_runs:
        plt.plot(time_steps, run, color=colors["I"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 2], label="Infected", color='darkred', linewidth=2)
    
    for run in R_runs:
        plt.plot(time_steps, run, color=colors["R"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 3], label="Recovered", color='darkgreen', linewidth=2)
    
    for run in Env_runs:
        plt.plot(time_steps, run, color=colors["Env"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 4], label="Environment", color='indigo', linewidth=2)
    
    plt.xlabel("Days")
    plt.ylabel("Total (summed over nodes)")
    plt.title("Behavioral Model (7 days)")
    plt.grid(True)
    legend = plt.legend(loc="right", fontsize=12)
    
    # Add text for R0 and TPI (placed within the plotting area)
    plt.text(0.78, 0.85, f"$R_0$: {R0_value}\nTPI: {TPI_value}", 
             transform=plt.gca().transAxes, fontsize=12, verticalalignment='center',
             bbox=dict(facecolor='white', alpha=0.6, edgecolor='black'))
    
    plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/DTM/figures/st_SEIR_7_hmm.jpg',
                dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
    plt.show()

#%% Example Usage of the Updated Plot Function

# (You can still compute R0 and TPI as before. Here we use your sample strings.)
R0_value = "1.56 ± 0.42"
TPI_value = "74.29 ± 6.59 days"

plot_all_runs_with_median_and_env(all_runs, median_results, days, R0_value, TPI_value)
#%%

# (Re-use g_indirect7 from your earlier code)
graph = g_indirect30  
days = 365
initial_infected = [5]

# Parameter ranges (same as before; these now drive both network and environment components)
beta_range = (0.05, 0.2)        # network transmission rate
gamma_range = (0.07, 0.14)        # recovery rate
sigma_range = (0.1, 0.25)        # progression from E to I
decay_rate = 0.16               # environmental decay rate
shedding_range = (0.2, 0.4)      # shedding rate into environment
acquisition_range = (0.2, 0.4)   # rate at which Env causes infection

scaling_factor = 1
max_infectious_days = 30
iterations = 1000
#%%
median_results, all_runs = stochastic_seir_env_model_with_env(
    graph, days, initial_infected,
    beta_range, gamma_range, sigma_range,
    decay_rate, shedding_range, acquisition_range,
    scaling_factor, max_infectious_days, iterations
)
#%%
# Re-use the sample_uniform function from before
def sample_uniform(param_range):
    """Sample a value uniformly from the given range."""
    return np.random.uniform(param_range[0], param_range[1])

def compute_stochastic_R0_env_only(gamma_range, shedding_range, acquisition_range, decay_rate, iterations=1000):
    """
    Computes the stochastic basic reproduction number (R0) for the environmental 
    indirect transmission only.
    
    The environmental R0 is calculated as:
        R0 = (shedding * acquisition) / (gamma * decay_rate)
    
    Parameters:
      - gamma_range: Tuple for the recovery rate.
      - shedding_range: Tuple for the environmental shedding rate.
      - acquisition_range: Tuple for the environmental acquisition rate.
      - decay_rate: Deterministic decay rate for the environmental compartment.
      - iterations: Number of stochastic samples to generate.
    
    Returns:
      - R0_values: NumPy array of computed R0 values (one per iteration).
      - R0_median: Median value of R0 from the iterations.
    """
    R0_values = []

    for _ in range(iterations):
        # Sample the stochastic parameters
        gamma = sample_uniform(gamma_range)
        shedding = sample_uniform(shedding_range)
        acquisition = sample_uniform(acquisition_range)

        # Compute R0 from the environmental route only
        R0 = (shedding * acquisition) / (gamma * decay_rate)
        R0_values.append(R0)

    R0_values = np.array(R0_values)
    R0_median = np.median(R0_values)
    return R0_values, R0_median

#%% Example usage:

# Define parameter ranges (using your 7-day persistence example values)
gamma_range = (0.07, 0.14)         # Recovery rate
shedding_range = (0.2, 0.4)         # Environmental shedding rate
acquisition_range = (0.2, 0.4)      # Environmental acquisition rate
decay_rate = 0.16                # Environmental decay rate

iterations = 1000  # Number of stochastic runs

# Compute stochastic R0 for environmental transmission only
R0_values, R0_median = compute_stochastic_R0_env_only(gamma_range, shedding_range, acquisition_range, decay_rate, iterations)

# Display the results
print(f"Mean Environmental R0: {np.mean(R0_values):.3f}")
print(f"Standard Deviation of Environmental R0: {np.std(R0_values):.3f}")
#%%
def calculate_time_to_peak(all_runs):
    """
    Calculate the time to peak incidence for each stochastic run.
    
    Parameters:
      - all_runs: List of arrays from your simulation. Each array should be of shape (days, 4)
                  where column 2 corresponds to the Infected (I) compartment.
    
    Returns:
      - mean_time_to_peak: The mean day of peak incidence across runs.
      - std_time_to_peak: The standard deviation of the peak day across runs.
      - time_to_peak_list: A list of the peak day (time index) for each run.
    """
    time_to_peak_list = []
    
    # Loop over each simulation run
    for run in all_runs:
        # Extract the infectious time series (assuming column 2 corresponds to I)
        I_series = run[:, 2]
        # Find the day (index) when I is maximal
        peak_day = np.argmax(I_series)
        time_to_peak_list.append(peak_day)
    
    mean_time_to_peak = np.mean(time_to_peak_list)
    std_time_to_peak = np.std(time_to_peak_list)
    
    return mean_time_to_peak, std_time_to_peak, time_to_peak_list
#%% 
# Calculate time to peak incidence:
mean_peak, std_peak, peak_list = calculate_time_to_peak(all_runs)
print(f"Time to peak incidence: {mean_peak:.2f} ± {std_peak:.2f} days")

#%% Updated Plotting Function (including Environment)

def plot_all_runs_with_median_and_env(all_runs, median_results, days, R0_value, TPI_value):
    """
    Plots all stochastic SEIR runs (with an added environmental compartment) along with the median trajectory.
    The five compartments are: S, E, I, R, and Env.
    
    Parameters:
      - all_runs: List of simulation runs (each: days x 5 array).
      - median_results: Median values over iterations (days x 5).
      - days: Number of simulation days.
      - R0_value: A string summarizing the reproduction number (e.g., "2.48 ± 0.63").
      - TPI_value: A string for total pathogen impact (e.g., "36.20 ± 2.01 days").
    """
    time_steps = np.arange(days)
    all_runs_array = np.array(all_runs)  # shape: (iterations, days, 5)
    
    # Extract compartments across runs:
    S_runs = all_runs_array[:, :, 0]
    E_runs = all_runs_array[:, :, 1]
    I_runs = all_runs_array[:, :, 2]
    R_runs = all_runs_array[:, :, 3]
    Env_runs = all_runs_array[:, :, 4]
    
    # Define colors for each compartment
    colors = {
        "S": "blue", 
        "E": "orange", 
        "I": "red", 
        "R": "green",
        "Env": "purple"
    }
    
    plt.figure(figsize=(12, 8))
    
    # Plot all iterations in light lines, then overplot the median in a darker (or thicker) line.
    for run in S_runs:
        plt.plot(time_steps, run, color=colors["S"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 0], label="Susceptible", color='darkblue', linewidth=2)
    
    for run in E_runs:
        plt.plot(time_steps, run, color=colors["E"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 1], label="Exposed", color='darkorange', linewidth=2)
    
    for run in I_runs:
        plt.plot(time_steps, run, color=colors["I"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 2], label="Infected", color='darkred', linewidth=2)
    
    for run in R_runs:
        plt.plot(time_steps, run, color=colors["R"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 3], label="Recovered", color='darkgreen', linewidth=2)
    
    for run in Env_runs:
        plt.plot(time_steps, run, color=colors["Env"], alpha=0.1, linewidth=0.5)
    plt.plot(time_steps, median_results[:, 4], label="Environment", color='indigo', linewidth=2)
    
    plt.xlabel("Days")
    plt.ylabel("Total (summed over nodes)")
    plt.title("Behavioral Model (30 days)")
    plt.grid(True)
    legend = plt.legend(loc="right", fontsize=12)
    
    # Add text for R0 and TPI (placed within the plotting area)
    plt.text(0.78, 0.85, f"$R_0$: {R0_value}\nTPI: {TPI_value}", 
             transform=plt.gca().transAxes, fontsize=12, verticalalignment='center',
             bbox=dict(facecolor='white', alpha=0.6, edgecolor='black'))
    
    plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/DTM/figures/st_SEIR_30_hmm.jpg',
                dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
    plt.show()

#%% Example Usage of the Updated Plot Function

# (You can still compute R0 and TPI as before. Here we use your sample strings.)
R0_value = "5.12 ± 1.57"
TPI_value = "90.17 ± 3.63 days"

plot_all_runs_with_median_and_env(all_runs, median_results, days, R0_value, TPI_value)
#%%
