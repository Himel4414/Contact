

"""
Extract and weight with Visitation rate

"""
#%%
import geopandas as gpd
import pandas as pd
import numpy as np
from shapely.geometry import Point
import os
#%%
visit = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use_u.shp")
print(visit)
#%%
### Get the high use areas as a new column in the contact data
def process_csv_files(directory, shapefile_path, crs='EPSG:32617'):
    # Load and concatenate CSV files
    csv_files = [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith('.csv')]
    df = pd.concat((pd.read_csv(file) for file in csv_files), ignore_index=True)

    # Create GeoDataFrame from DataFrame
    gdf = gpd.GeoDataFrame(
        df,
        geometry=[Point(xy) for xy in zip(df.x, df.y)],
        crs='EPSG:32617'
    )

    # Load shapefile and filter points
    shp = gpd.read_file(shapefile_path)
    shp = shp.to_crs(epsg=32617)
    gdf['high_use'] = gdf.geometry.apply(lambda point: any(shp.intersects(point)))
    gdf['high_use'] = gdf['high_use'].astype(int)

    return gdf[gdf['high_use'] == 1]
#%%
shapefile_path = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use_u.shp"
#%%
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d1/"
gdf1 = process_csv_files(directory, shapefile_path)
df1 = gdf1.drop(columns='geometry')
df1.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_raw_1.csv', index=False)
print(df1)
#%%
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d2/"
gdf2 = process_csv_files(directory, shapefile_path)
df2 = gdf2.drop(columns='geometry')
df2.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_raw_2.csv', index=False)
print(df2)
#%%
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d3/"
gdf3 = process_csv_files(directory, shapefile_path)
df3 = gdf3.drop(columns='geometry')
df3.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_raw_3.csv', index=False)
print(df3)
#%%
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d4/"
gdf4 = process_csv_files(directory, shapefile_path)
df4 = gdf4.drop(columns='geometry')
df4.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_raw_4.csv', index=False)
print(df4)
#%%

# Function to process a list of DataFrames
def process_dataframes(dataframes, time_limit, decay_rate):
    # Concatenate all the DataFrames in the list
    data = pd.concat(dataframes, ignore_index=True)
    
    # Check if the concatenated DataFrame is empty
    if data.empty:
        print("No data found in the provided DataFrames.")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    # Determine 'from' and 'to' based on datetime comparison
    data['from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data['to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    
    # Calculate time difference in seconds and convert to days
    data['diff'] = (data['datetime1'] - data['datetime2']).abs()
    data['timediff'] = data['diff'] / 86400
    
    # Filter data based on the provided time limit
    data = data[data['timediff'] <= time_limit]
    if data.empty:
        print("No rows within time limit in the provided DataFrames.")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    # Calculate weights using an exponential decay based on 'timediff'
    data['weight'] = np.exp(-decay_rate * data['timediff'])    
    # Group by 'from', 'to' and sum the weights
    result = data.groupby(['from', 'to'], as_index=False).agg({'weight': 'sum'})
    
    return result
#%%
con_7 = process_dataframes([df1, df2, df3, df4], time_limit=7, decay_rate=0.7)
con_7['pair'] = con_7.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)
print(con_7)
#%%
con_30 = process_dataframes([df1, df2, df3, df4], time_limit=30, decay_rate=0.16)
con_30['pair'] = con_30.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)
print(con_30)
#%%
con_7.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_7days_hu.csv", index=False)
con_30.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_30days_hu.csv", index=False)
#%%
df1 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_raw_1.csv')
df2 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_raw_2.csv')
df3 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_raw_3.csv')
df4 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_raw_4.csv')
#%%
# Function to calculate overlap
def calculate_overlap(data):
    data['from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data['to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    data['pair'] = data.apply(lambda row: f"{int(row['id1'])}_{int(row['id2'])}", axis=1)
    
    overlap = data.groupby('pair').agg(
        min_datetime1=('datetime1', 'min'),
        max_datetime1=('datetime1', 'max'),
        min_datetime2=('datetime2', 'min'),
        max_datetime2=('datetime2', 'max')
    ).reset_index()
    
    overlap['overlap_start'] = overlap[['min_datetime1', 'min_datetime2']].max(axis=1)
    overlap['overlap_end'] = overlap[['max_datetime1', 'max_datetime2']].min(axis=1)
    overlap['overlap'] = (overlap['overlap_end'] - overlap['overlap_start']).abs()
    overlap['overlap_days'] = overlap['overlap'] / 86400
    return overlap[['pair', 'overlap_days']]

# Function to load and process overlap data
def load_and_calculate_overlap(dfs):
    data = pd.concat(dfs, ignore_index=True)
    return calculate_overlap(data)
#%%
# Calculate overlap
overlap = load_and_calculate_overlap([df1, df2, df3, df4])
print(overlap)

#%%
reversed_overlap = overlap.copy()
reversed_overlap['pair'] = overlap['pair'].apply(lambda x: '_'.join(x.split('_')[::-1]))
overlap = pd.concat([overlap, reversed_overlap], ignore_index=True)
#%%
overlap.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/overlap.csv", index=False)
print(overlap)
#%%
# Load indirect contact data
indir_7 = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_7days_hu.csv")
indir_30 = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_30days_hu.csv")
#%%
# Add overlap data
indir_7_pd_hu = indir_7.merge(overlap[['pair', 'overlap_days']], on='pair', how='left')
indir_30_pd_hu = indir_30.merge(overlap[['pair', 'overlap_days']], on='pair', how='left')
print(indir_30_pd_hu)
#%%
# Calculate weight per day
indir_7_pd_hu['wpd'] = indir_7_pd_hu['weight'] / indir_7_pd_hu['overlap_days']
indir_30_pd_hu['wpd'] = indir_30_pd_hu['weight'] / indir_30_pd_hu['overlap_days']
#%%
# Save final datasets
indir_7_pd_hu[['from', 'to', 'weight', 'wpd']].to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_7days_pd_hu.csv", index=False)
indir_30_pd_hu[['from', 'to', 'weight', 'wpd']].to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_30days_pd_hu.csv", index=False)
# %%

################## For 7 days PD + HU
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
# %%
indir1_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_7days_pd_hu.csv")
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_30days_pd_hu.csv")
print(indir1_df)
# %%
# Define the corrected categories based on the range with a max of 2076
bins = [0, 35,  100, 200, 350, 600, 1000, 1500, 2000, np.inf]
labels = [
    '1',  '30', '100', '200', '350', '600', 
    '1000', '1500', '2076'
]
# %%
# Categorize the weights
indir1_df['wpd_category'] = pd.cut(indir1_df['wpd'], bins=bins, labels=labels, right=False)
# Get unique IDs
all_ids = np.unique(np.concatenate((indir1_df['from'], indir1_df['to'])))
# %%
# Create a matrix for the categorized weights
contact_matrix_categorical = np.full((len(all_ids), len(all_ids)), '', dtype=object)
for i, row in indir1_df.iterrows():
    id1, id2, category = row['from'], row['to'], row['wpd_category']
    contact_matrix_categorical[np.where(all_ids == id1)[0], np.where(all_ids == id2)[0]] = category

# %%
# Map the categories to numerical values for plotting
category_to_num = {label: i+1 for i, label in enumerate(labels)}
contact_matrix_numeric = np.vectorize(lambda x: category_to_num.get(x, 0))(contact_matrix_categorical)
# Convert the matrix to a DataFrame for easier plotting
contact_matrix_df = pd.DataFrame(contact_matrix_numeric, index=all_ids, columns=all_ids)
# Set zero values to NaN for displaying as white
contact_matrix_df = contact_matrix_df.replace(0, np.nan)

# %%
# Create a colormap for the bins
colors = sns.color_palette("OrRd", len(labels))
colors.insert(0, (1.0, 1.0, 1.0))  # Insert white at the beginning for NaN values
cmap = ListedColormap(colors)
norm = BoundaryNorm(boundaries=np.arange(len(labels)+2), ncolors=len(labels)+1)

# %%
# Calculate the figure size to make it square
fig_size = 10  # You can adjust this to make the entire figure larger or smaller

# Set the figure size and aspect ratio
plt.figure(figsize=(fig_size, fig_size))

# Create the heatmap with the custom colormap and square cells
sns.heatmap(contact_matrix_df, cmap=cmap, norm=norm, linewidths=0.05, linecolor='gray', square=True,
            cbar_kws={"orientation": "vertical", "pad": 0.1, "aspect": 20, "shrink": 0.5})

# Set the color bar labels
cbar = plt.gca().collections[0].colorbar
cbar.set_ticks(np.arange(1.5, len(labels)+1.5))
cbar.set_ticklabels(labels)
cbar.set_label('Contacts per Day')

# Plot diagonal line
plt.plot([0, len(all_ids)], [0, len(all_ids)], 'k--', lw=0.5)

# Set titles and labels
plt.title("7 days pathogen decay(upper limit")
plt.xlabel(" ")
plt.ylabel(" ")
plt.xticks(rotation=90)
plt.yticks(rotation=0)

# Save the plot as a JPG file with 1000x1000 dimensions
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_7_HU.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')

# Display the plot
plt.show()
# %%


################## For 30 days PD + HU

range2 = indir2_df['wpd'].sort_values()
print(range2.to_list())

# %%
# Categorize the weights
indir2_df['wpd_category'] = pd.cut(indir2_df['wpd'], bins=bins, labels=labels, right=False)
# Get unique IDs
all_ids = np.unique(np.concatenate((indir2_df['from'], indir2_df['to'])))
# %%
# Create a matrix for the categorized weights
contact_matrix_categorical = np.full((len(all_ids), len(all_ids)), '', dtype=object)
for i, row in indir2_df.iterrows():
    id1, id2, category = row['from'], row['to'], row['wpd_category']
    contact_matrix_categorical[np.where(all_ids == id1)[0], np.where(all_ids == id2)[0]] = category

# %%
# Map the categories to numerical values for plotting
category_to_num = {label: i+1 for i, label in enumerate(labels)}
contact_matrix_numeric = np.vectorize(lambda x: category_to_num.get(x, 0))(contact_matrix_categorical)
# Convert the matrix to a DataFrame for easier plotting
contact_matrix_df = pd.DataFrame(contact_matrix_numeric, index=all_ids, columns=all_ids)
# Set zero values to NaN for displaying as white
contact_matrix_df = contact_matrix_df.replace(0, np.nan)

# %%
# Create a colormap for the bins
colors = sns.color_palette("OrRd", len(labels))
colors.insert(0, (1.0, 1.0, 1.0))  # Insert white at the beginning for NaN values
cmap = ListedColormap(colors)
norm = BoundaryNorm(boundaries=np.arange(len(labels)+2), ncolors=len(labels)+1)

# %%
# Calculate the figure size to make it square
fig_size = 10  # You can adjust this to make the entire figure larger or smaller

# Set the figure size and aspect ratio
plt.figure(figsize=(fig_size, fig_size))

# Create the heatmap with the custom colormap and square cells
sns.heatmap(contact_matrix_df, cmap=cmap, norm=norm, linewidths=0.05, linecolor='gray', square=True,
            cbar_kws={"orientation": "vertical", "pad": 0.1, "aspect": 20, "shrink": 0.5})

# Set the color bar labels
cbar = plt.gca().collections[0].colorbar
cbar.set_ticks(np.arange(1.5, len(labels)+1.5))
cbar.set_ticklabels(labels)
cbar.set_label('Contacts per Day')

# Plot diagonal line
plt.plot([0, len(all_ids)], [0, len(all_ids)], 'k--', lw=0.5)

# Set titles and labels
plt.title("30 days pathogen decay(upper limit")
plt.xlabel(" ")
plt.ylabel(" ")
plt.xticks(rotation=90)
plt.yticks(rotation=0)

# Save the plot as a JPG file with 1000x1000 dimensions
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_30_HU.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')

# Display the plot
plt.show()
#%%
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import numpy as np
import panel as pn
#%%
indir1_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_7days_pd_hu.csv")
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir_30days_pd_hu.csv")
#%%
indir1_df = indir1_df.iloc[:,[0,1,3]]
indir2_df = indir2_df.iloc[:,[0,1,3]]
indir1_df.columns = ["id1", "id2", "weight"]
indir2_df.columns = ["id1", "id2", "weight"]
indir1_df['id1'] = indir1_df['id1'].astype(str)
indir1_df['id2'] = indir1_df['id2'].astype(str)
indir2_df['id1'] = indir2_df['id1'].astype(str)
indir2_df['id2'] = indir2_df['id2'].astype(str)

#%%
g_indirect7 = nx.from_pandas_edgelist(indir1_df, source='id1', target='id2', edge_attr='weight', create_using=nx.DiGraph())
g_indirect30 = nx.from_pandas_edgelist(indir2_df, source='id1', target='id2', edge_attr='weight', create_using=nx.DiGraph())
#%%
# Get all unique nodes
all_nodes = (set(g_indirect7.nodes())).union(set(g_indirect30.nodes()))
g_indirect7.add_nodes_from(all_nodes - set(g_indirect7.nodes()))
g_indirect30.add_nodes_from(all_nodes - set(g_indirect30.nodes()))
#%%
# Adjust weights
for g in [ g_indirect7, g_indirect30]:
    for u, v, d in g.edges(data=True):
        d['weight'] = np.log(d['weight'] + 1)
#%%
# Read the sex information
sex = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/OriginalData/sex_pig.csv")
sex['id'] = sex['id'].astype(str)
sex_dict = dict(zip(sex['id'], sex['sex']))
#%%
# Assign sex information to nodes
for g in [ g_indirect7, g_indirect30]:
    for node in g.nodes():
        g.nodes[node]['sex'] = sex_dict.get(node, 'F')
#%%
# Function to get node colors
vertex_colors = {"M": "lightgreen", "F": "pink"}
def get_node_colors(g):
    return [vertex_colors[g.nodes[n]['sex']] for n in g.nodes]
#%%
import pickle

# Load the layout from the file
with open('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/layout_all.pkl', 'rb') as f:
    layout_all = pickle.load(f)
    
    #%%
    # Define common parameters
    vertex_size = 1500
    vertex_label_fontsize = 18
    edge_color = "darkgrey"
    
    #%%
    # Plot Indirect Contacts with 7 days Pathogen Decay
    plt.figure(figsize=(12, 12))
    nx.draw(g_indirect7, pos=layout_all, with_labels=True, node_color=get_node_colors(g_indirect7), 
            node_size=vertex_size, edge_color=edge_color, font_size=vertex_label_fontsize,
           width=[np.log(d['weight'])*0.9 for u, v, d in g_indirect7.edges(data=True)],
            arrowsize=20, connectionstyle='arc3,rad=0.2')
    plt.title("Indirect Contacts with Pathogen Decay (7 days)")
    # Add the legend
    #male_legend = mlines.Line2D([], [], color='lightgreen', marker='o', linestyle='None', markersize=12, label='Male')
    #female_legend = mlines.Line2D([], [], color='pink', marker='o', linestyle='None', markersize=12, label='Female')
    #plt.legend(handles=[male_legend, female_legend], loc='best', title='Sex')

    plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir7_net_hu.jpg', 
                dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
    plt.show()

    #%%
    # Plot Indirect Contacts with 30 days Pathogen Decay
    plt.figure(figsize=(12, 12))
    nx.draw(g_indirect30, pos=layout_all, with_labels=True, node_color=get_node_colors(g_indirect30), 
            node_size=vertex_size, edge_color=edge_color, font_size=vertex_label_fontsize,
            width=[np.log(d['weight'])*1 for u, v, d in g_indirect30.edges(data=True)],
            arrowsize=20, connectionstyle='arc3,rad=0.2')
    plt.title("Indirect Contacts with Pathogen Decay (30 days)")
    # Add the legend
    #male_legend = mlines.Line2D([], [], color='lightgreen', marker='o', linestyle='None', markersize=12, label='Male')
    #female_legend = mlines.Line2D([], [], color='pink', marker='o', linestyle='None', markersize=12, label='Female')
    #plt.legend(handles=[male_legend, female_legend], loc='best', title='Sex')

    plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/upper/indir30_net_hu.jpg', 
                dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
    plt.show()
    #%%

    """
    Network_Matrix
    """

    #%%
    import networkx as nx
    import pandas as pd
    import numpy as np
    from scipy import stats
    import seaborn as sns
    import community as community_louvain
    import matplotlib.pyplot as plt
#%%
def process_graph(indir_df, title):
    # Process the dataframe to extract necessary columns
    indir_df = indir_df.iloc[:, [0, 1, 3]]
    indir_df.columns = ["id1", "id2", "weight"]

    # Create a directed graph
    G = nx.DiGraph()
    
    # Add weighted edges to the graph
    for idx, row in indir_df.iterrows():
        G.add_edge(row['id1'], row['id2'], weight=row['weight'])
    
    # Modularity (using Louvain community detection)
    partition = community_louvain.best_partition(nx.Graph(G))  # Treat as undirected for community detection
    modularity = community_louvain.modularity(partition, nx.Graph(G))
    print(f"Modularity ({title}):", modularity)

    # Calculate network metrics
    transitivity = nx.transitivity(G)
    edge_density = nx.density(G)
    assortativity = nx.degree_pearson_correlation_coefficient(G)
    outdegree = dict(G.out_degree())
    indegree = dict(G.in_degree())
    outstrength = dict(G.out_degree(weight='weight'))
    instrength = dict(G.in_degree(weight='weight'))
    closeness = nx.closeness_centrality(G)
    betweenness = nx.betweenness_centrality(G, weight='weight')

    # Print key metrics
    print(f"Transitivity ({title}):", transitivity)
    mean_close = sum(closeness.values()) / len(closeness)
    print(f"Mean Closeness ({title}):", mean_close)
    
    # Eigenvector centrality calculation
    try:
        eigenvector = nx.eigenvector_centrality(G, max_iter=10000, tol=1e-06, weight='weight')
        mean_eigenvector = sum(eigenvector.values()) / len(eigenvector)
        print(f"Mean Eigenvector Centrality ({title}):", mean_eigenvector)
        print(f"Eigenvector Centrality ({title}):", eigenvector)  # Print the actual eigenvector values
    except nx.PowerIterationFailedConvergence:
        print(f"Eigenvector centrality did not converge for {title}.")
        eigenvector = None

    mean_bet = sum(betweenness.values()) / len(betweenness)
    print(f"Mean Betweenness ({title}):", mean_bet)
    print(f"Edge Density ({title}):", edge_density)
    print(f"Assortativity ({title}):", assortativity)

    # Degree and strength metrics as numpy arrays
    outdegree_vals = np.array(list(outdegree.values()))
    indegree_vals = np.array(list(indegree.values()))
    outstrength_vals = np.array(list(outstrength.values()))
    instrength_vals = np.array(list(instrength.values()))

    # Fit distributions
    def fit_distribution(data, metric_title):
        dist_names = ["norm", "expon", "lognorm", "gamma"]
        dist_results = []
        params = {}

        for dist_name in dist_names:
            dist = getattr(stats, dist_name)
            param = dist.fit(data)
            params[dist_name] = param
            # Perform the Kolmogorov-Smirnov test
            D, p = stats.kstest(data, dist_name, args=param)
            dist_results.append((dist_name, p))

        # Special case for Poisson distribution
        poisson_param = np.mean(data)
        D, p = stats.kstest(data, 'poisson', args=(poisson_param,))
        dist_results.append(('poisson', p))
        params['poisson'] = (poisson_param,)

        # Select the best fitted distribution
        best_dist, best_p = max(dist_results, key=lambda item: item[1])

        # Plot the histogram and the best fit distribution
        plt.figure(figsize=(12, 8))
        sns.histplot(data, bins=30, kde=False, color='blue', stat='density')

        if best_dist == 'poisson':
            best_param = params['poisson']
            x = np.arange(min(data), max(data) + 1)
            pmf = stats.poisson.pmf(x, *best_param)
            plt.plot(x, pmf, label=f'{best_dist}', color='red')
        else:
            best_dist_obj = getattr(stats, best_dist)
            best_param = params[best_dist]
            pdf = best_dist_obj.pdf(np.linspace(min(data), max(data), 100), *best_param[:-2], loc=best_param[-2], scale=best_param[-1])
            plt.plot(np.linspace(min(data), max(data), 100), pdf, label=f'{best_dist}', color='red')

        plt.title(f'{metric_title}\nBest fit distribution: {best_dist}')
        plt.legend()
        plt.show()

        return best_dist, params.get(best_dist, None)

    # Fit and plot distributions for each metric
    best_outdegree_dist, outdegree_params = fit_distribution(outdegree_vals, f"Out-Degree Distribution ({title})")
    best_indegree_dist, indegree_params = fit_distribution(indegree_vals, f"In-Degree Distribution ({title})")
    best_outstrength_dist, outstrength_params = fit_distribution(outstrength_vals, f"Out-Strength Distribution ({title})")
    best_instrength_dist, instrength_params = fit_distribution(instrength_vals, f"In-Strength Distribution ({title})")

    # Calculate ranges
    outdegree_range = (np.min(outdegree_vals), np.max(outdegree_vals))
    indegree_range = (np.min(indegree_vals), np.max(indegree_vals))
    outstrength_range = (np.min(outstrength_vals), np.max(outstrength_vals))
    instrength_range = (np.min(instrength_vals), np.max(instrength_vals))

    # Display the results
    print(f"Best fit distribution for Out-Degree ({title}):", best_outdegree_dist, outdegree_params)
    print(f"Best fit distribution for In-Degree ({title}):", best_indegree_dist, indegree_params)
    print(f"Best fit distribution for Out-Strength ({title}):", best_outstrength_dist, outstrength_params)
    print(f"Best fit distribution for In-Strength ({title}):", best_instrength_dist, instrength_params)
    print(f"Range for Out-Degree ({title}):", outdegree_range)
    print(f"Range for In-Degree ({title}):", indegree_range)
    print(f"Range for Out-Strength ({title}):", outstrength_range)
    print(f"Range for In-Strength ({title}):", instrength_range)
#%%
indir1_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/indir_7days_pd_hu.csv")
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/indir_30days_pd_hu.csv")
#%
 #%%
 # Process the graphs for both datasets
process_graph(indir1_df, "7 Days Pathogen Decay")
 #%%
process_graph(indir2_df, "30 Days Pathogen Decay")
 #%%