# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 12:35:49 2024

@author: himel
"""
# %%
import geopandas as gpd
import matplotlib.pyplot as plt
#%%
# Load the shapefiles
high_use = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use.shp")
high_use_u = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use_u.shp")
high_use_l = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use_l.shp")

# %%
vector_data = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/contact_net/shp_base/shape_bg.shp")
base = vector_data[vector_data['points'] != 0].copy()
# %%

# Define the plot size
fig, axes = plt.subplots(1, 3, figsize=(18, 6), sharex=True, sharey=True)

# Plot background vector data in grey
for ax in axes:
    base.plot(ax=ax, color='grey', edgecolor='none', alpha=0.2)

# Plot each shapefile on top of the background
high_use_l.plot(ax=axes[2], color='blue', edgecolor='none', alpha=1)
axes[2].set_title('High Use (0.5)')

high_use.plot(ax=axes[1], color='green', edgecolor='none', alpha=1)
axes[1].set_title('High Use  (0.75)')

high_use_u.plot(ax=axes[0], color='red', edgecolor='none', alpha=1)
axes[0].set_title('High Use  (0.9)')

# Remove axis labels and ticks
for ax in axes:
    ax.set_xlabel('')
    ax.set_ylabel('')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_xticklabels([])
    ax.set_yticklabels([])

# Adjust layout and save
plt.tight_layout()
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/high_use.jpg',
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()


# %%
