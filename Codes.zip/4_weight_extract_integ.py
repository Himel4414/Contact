"""
Extract weight for integrated model
"""
#%%
import os
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point

#%% Load visitation data (high-use areas)
shapefile_path = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use.shp"
visit = gpd.read_file(shapefile_path)
visit = visit.to_crs(epsg=32617)

#%% Define paths for contact data directories
directories = [
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d1/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d2/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d3/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d4/"
]

#%% Load and process high-use areas
def process_high_use_areas(directory, shapefile_path):
    csv_files = [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith('.csv')]
    df = pd.concat((pd.read_csv(file) for file in csv_files), ignore_index=True)

    gdf = gpd.GeoDataFrame(
        df,
        geometry=[Point(xy) for xy in zip(df.x, df.y)],
        crs='EPSG:32617'
    )

    # Add high-use column based on spatial intersection with visitation areas
    gdf['high_use'] = gdf.geometry.apply(lambda point: any(visit.intersects(point)))
    gdf['high_use'] = gdf['high_use'].astype(int)

    return gdf[gdf['high_use'] == 1]

#%% Process contact data by high-use areas
all_high_use_dfs = []
for directory in directories:
    gdf_high_use = process_high_use_areas(directory, shapefile_path)
    df_high_use = gdf_high_use.drop(columns='geometry')
    all_high_use_dfs.append(df_high_use)

# Combine all high-use dataframes
combined_high_use_df = pd.concat(all_high_use_dfs, ignore_index=True)
combined_high_use_df.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/combined_high_use.csv', index=False)
print(combined_high_use_df)

#%% Load HMM data and add behavior states
hmm_data = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/pig_data/pig_data_hmm.csv')
hmm_data['id'] = hmm_data['id'].astype(int)
hmm_data['state'] = hmm_data['states'].map({0: 'resting', 1: 'foraging', 2: 'moving'})

#%% Filter based on high-use areas and behavior relevance
def filter_relevant_contacts(df, hmm_data):
    # Merge HMM data for both id1 and id2
    df = df.merge(hmm_data[['id', 'time_s', 'state']], how='left', left_on=['id1', 'datetime1'], right_on=['id', 'time_s'])
    df.rename(columns={'state': 'state1'}, inplace=True)
    df.drop(columns=['id', 'time_s'], inplace=True)

    df = df.merge(hmm_data[['id', 'time_s', 'state']], how='left', left_on=['id2', 'datetime2'], right_on=['id', 'time_s'])
    df.rename(columns={'state': 'state2'}, inplace=True)
    df.drop(columns=['id', 'time_s'], inplace=True)

    # Filter based on behavioral states relevant for transmission
    filtered_df = df[
        ((df['state1'] == 'resting') & (df['state2'] == 'resting')) |
        ((df['state1'] == 'resting') & (df['state2'] == 'foraging')) |
        ((df['state1'] == 'foraging') & (df['state2'] == 'resting')) |
        ((df['state1'] == 'foraging') & (df['state2'] == 'foraging'))
    ].copy()

    return filtered_df

#%% Apply behavior filtering
relevant_contacts_df = filter_relevant_contacts(combined_high_use_df, hmm_data)
print(relevant_contacts_df)
# Save the filtered dataset
relevant_contacts_df.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_raw_integ.csv', index=False)

#%% Calculate overlap and weight (integrated method)
def calculate_weights(df, time_limit, decay_rate, output_path):
    df['datetime1'] = pd.to_numeric(df['datetime1'], errors='coerce')
    df['datetime2'] = pd.to_numeric(df['datetime2'], errors='coerce')
    df['from'] = np.where(df['datetime1'] <= df['datetime2'], df['id1'], df['id2'])
    df['to'] = np.where(df['datetime1'] <= df['datetime2'], df['id2'], df['id1'])
    df['diff'] = (df['datetime1'] - df['datetime2']).abs()
    df['timediff'] = df['diff'] / 86400  # Convert seconds to days

    df = df[df['timediff'] <= time_limit]
    df['weight'] = np.exp(-decay_rate * df['timediff'])

    # Group by 'from' and 'to' and sum the weights
    weighted_contacts = df.groupby(['from', 'to']).agg({'weight': 'sum'}).reset_index()

    # Save the final weighted contacts
    weighted_contacts.to_csv(output_path, index=False)

#%% Calculate weights for 7 days and 30 days
time_limits = [7, 30]
decay_rates = [0.7, 0.16]
output_paths = [
    'C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_7_days.csv',
    'C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_30_days.csv'
]

for time_limit, decay_rate, output_path in zip(time_limits, decay_rates, output_paths):
    calculate_weights(relevant_contacts_df.copy(), time_limit, decay_rate, output_path)
#%% Calculate overlap days
def calculate_overlap(data):
    data['datetime1'] = pd.to_numeric(data['datetime1'], errors='coerce')
    data['datetime2'] = pd.to_numeric(data['datetime2'], errors='coerce')
    data['from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data['to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    data['pair'] = data.apply(lambda row: f"{int(row['id1'])}_{int(row['id2'])}", axis=1)

    overlap = data.groupby('pair').agg(
        min_datetime1=('datetime1', 'min'),
        max_datetime1=('datetime1', 'max'),
        min_datetime2=('datetime2', 'min'),
        max_datetime2=('datetime2', 'max')
    ).reset_index()

    overlap['overlap_start'] = overlap[['min_datetime1', 'min_datetime2']].max(axis=1)
    overlap['overlap_end'] = overlap[['max_datetime1', 'max_datetime2']].min(axis=1)
    overlap['overlap'] = (overlap['overlap_end'] - overlap['overlap_start']).abs()
    overlap['overlap_days'] = overlap['overlap'] / 86400  # Convert seconds to days

    return overlap[['pair', 'overlap_days']]

#%% Calculate overlap for relevant contacts
overlap_df = calculate_overlap(relevant_contacts_df)
overlap_rev = overlap_df.copy()
overlap_rev['pair'] = overlap_rev['pair'].apply(lambda x: '_'.join(x.split('_')[::-1]))

# Combine the original 'overlap' DataFrame with the revised 'overlap_rev'
combined_overlap = pd.concat([overlap_df, overlap_rev], ignore_index=True)
# Save overlap data
combined_overlap.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/overlap_days.csv', index=False)
#%% Load indirect contact data
indir_7 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_7_days.csv')
indir_7['pair'] = indir_7.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)

indir_30 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_30_days.csv')
indir_30['pair'] = indir_30.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)

#%% Add overlap data
indir_7_pd = indir_7.merge(combined_overlap[['pair', 'overlap_days']], on='pair', how='left')
indir_30_pd = indir_30.merge(combined_overlap[['pair', 'overlap_days']], on='pair', how='left')

print(indir_30_pd)

#%% Calculate weight per day
indir_7_pd['wpd'] = indir_7_pd['weight'] / indir_7_pd['overlap_days']
indir_30_pd['wpd'] = indir_30_pd['weight'] / indir_30_pd['overlap_days']

#%% Save final datasets
indir_7_pd[['from', 'to', 'weight', 'wpd']].to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_7_pd.csv', index=False)
indir_30_pd[['from', 'to', 'weight', 'wpd']].to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_30_pd.csv", index=False)
#%%