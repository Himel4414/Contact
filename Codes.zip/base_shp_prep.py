# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 21:18:47 2024

@author: himel
"""

#%%
import geopandas as gpd
from shapely.geometry import Point
import pandas as pd
from tqdm import tqdm

#%%
# Load grid shapefile and GPS data
grid = gpd.read_file("C:/Users/himel\OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/Environment/area.shp")
print(grid)
#%%
gps_data = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/pig_data/pig_data.csv')
print(gps_data)
#%%
# Convert GPS data to a GeoDataFrame
geometry = [Point(xy) for xy in zip(gps_data['x'], gps_data['y'])]
gps_geo = gpd.GeoDataFrame(gps_data, geometry=geometry)

# Set CRS for both datasets to UTM Zone 17 (EPSG:32617)
utm_crs = 'EPSG:32617'
grid.set_crs(utm_crs, inplace=True)
gps_geo.set_crs(utm_crs, inplace=True)
#%%
# Add progress bar
tqdm.pandas()

# Create a new column in the shapefile to indicate presence of GPS points
grid['points'] = grid.progress_apply(
    lambda row: any(gps_geo.within(row.geometry)), axis=1
).astype(int)
#%%
print(grid)
# Save the updated shapefile if necessary
grid.to_file('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/contact_net/shp_base/shape_bg.shp')
#%%