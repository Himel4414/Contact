
"""
Network_graph
"""
#%%
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import numpy as np
import panel as pn
#%%
indir1_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_7_pd.csv")
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_30_pd.csv")

#%%
indir1_df = indir1_df.iloc[:,[0,1,3]]
indir2_df = indir2_df.iloc[:,[0,1,3]]
indir1_df.columns = ["id1", "id2", "weight"]
indir2_df.columns = ["id1", "id2", "weight"]
indir1_df['id1'] = indir1_df['id1'].astype(str)
indir1_df['id2'] = indir1_df['id2'].astype(str)
indir2_df['id1'] = indir2_df['id1'].astype(str)
indir2_df['id2'] = indir2_df['id2'].astype(str)
#%%
g_indirect7 = nx.from_pandas_edgelist(indir1_df, source='id1', target='id2', edge_attr='weight', create_using=nx.DiGraph())
g_indirect30 = nx.from_pandas_edgelist(indir2_df, source='id1', target='id2', edge_attr='weight', create_using=nx.DiGraph())
#%%
# Get all unique nodes
all_nodes = (set(g_indirect7.nodes())).union(set(g_indirect30.nodes()))
g_indirect7.add_nodes_from(all_nodes - set(g_indirect7.nodes()))
g_indirect30.add_nodes_from(all_nodes - set(g_indirect30.nodes()))
#%%
# Adjust weights
for g in [ g_indirect7, g_indirect30]:
    for u, v, d in g.edges(data=True):
        d['weight'] = np.log(d['weight'] + 1)
#%%
# Read the sex information
sex = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/OriginalData/sex_pig.csv")
sex['id'] = sex['id'].astype(str)
sex_dict = dict(zip(sex['id'], sex['sex']))
#%%
# Assign sex information to nodes
for g in [ g_indirect7, g_indirect30]:
    for node in g.nodes():
        g.nodes[node]['sex'] = sex_dict.get(node, 'F')
#%%
# Function to get node colors
vertex_colors = {"M": "lightgreen", "F": "pink"}
def get_node_colors(g):
    return [vertex_colors[g.nodes[n]['sex']] for n in g.nodes]
#%%
import pickle

# Load the layout from the file
with open('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/layout_all.pkl', 'rb') as f:
    layout_all = pickle.load(f)
#%%
# Define common parameters
vertex_size = 1500
vertex_label_fontsize = 18
edge_color = "darkgrey"
#%%
# Plot Indirect Contacts with 7 days Pathogen Decay
plt.figure(figsize=(12, 12))
nx.draw(g_indirect7, pos=layout_all, with_labels=True, node_color=get_node_colors(g_indirect7), 
        node_size=vertex_size, edge_color=edge_color, font_size=vertex_label_fontsize,
       width=[np.log(d['weight'])*0.9 for u, v, d in g_indirect7.edges(data=True)],
        arrowsize=20, connectionstyle='arc3,rad=0.2')
plt.title("Indirect Contacts with Pathogen Decay (7 days)")
# Add the legend
male_legend = mlines.Line2D([], [], color='lightgreen', marker='o', linestyle='None', markersize=12, label='Male')
female_legend = mlines.Line2D([], [], color='pink', marker='o', linestyle='None', markersize=12, label='Female')
plt.legend(handles=[male_legend, female_legend], loc='best', title='Sex', fontsize=18, title_fontsize=20)

plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/indir7_net.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()

#%%
# Plot Indirect Contacts with 30 days Pathogen Decay
plt.figure(figsize=(12, 12))
nx.draw(g_indirect30, pos=layout_all, with_labels=True, node_color=get_node_colors(g_indirect30), 
        node_size=vertex_size, edge_color=edge_color, font_size=vertex_label_fontsize,
        width=[np.log(d['weight'])*1 for u, v, d in g_indirect30.edges(data=True)],
        arrowsize=20, connectionstyle='arc3,rad=0.2')
plt.title("Indirect Contacts with Pathogen Decay (30 days)")
# Add the legend
#male_legend = mlines.Line2D([], [], color='lightgreen', marker='o', linestyle='None', markersize=12, label='Male')
#female_legend = mlines.Line2D([], [], color='pink', marker='o', linestyle='None', markersize=12, label='Female')
#plt.legend(handles=[male_legend, female_legend], loc='best', title='Sex')

plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/indir30_net.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()
#%%

"""
Network_Matrix
"""

#%%
import networkx as nx
import pandas as pd
import numpy as np
from scipy import stats
import seaborn as sns
import community as community_louvain
import matplotlib.pyplot as plt

#%%
def load_data(file_path):
    df = pd.read_csv(file_path)
    df = df.iloc[:, [0, 1, 3]]
    df.columns = ["id1", "id2", "weight"]
    return df

def create_graph(df):
    G = nx.DiGraph()
    for idx, row in df.iterrows():
        G.add_edge(row['id1'], row['id2'], weight=row['weight'])
    return G

def calculate_metrics(G):
    metrics = {
        'transitivity': nx.transitivity(G),
        'edge_density': nx.density(G),
        'assortativity': nx.degree_pearson_correlation_coefficient(G),
        'outdegree': dict(G.out_degree()),
        'indegree': dict(G.in_degree()),
        'outstrength': dict(G.out_degree(weight='weight')),
        'instrength': dict(G.in_degree(weight='weight')),
        'closeness': nx.closeness_centrality(G),
        'betweenness': nx.betweenness_centrality(G, weight='weight')
    }

    mean_metrics = {
        'mean_close': np.mean(list(metrics['closeness'].values())),
        'mean_betw': np.mean(list(metrics['betweenness'].values()))
    }

    try:
        metrics['eigenvector'] = nx.eigenvector_centrality(G, max_iter=10000, tol=1e-06, weight='weight')
        mean_metrics['mean_eigenvector'] = np.mean(list(metrics['eigenvector'].values()))
    except nx.PowerIterationFailedConvergence:
        print("Eigenvector centrality did not converge.")
        metrics['eigenvector'] = None
        mean_metrics['mean_eigenvector'] = None

    return metrics, mean_metrics

def calculate_modularity(G):
    partition = community_louvain.best_partition(nx.Graph(G))
    modularity = community_louvain.modularity(partition, nx.Graph(G))
    return modularity

def fit_distribution(data, title):
    dist_names = ["norm", "expon", "lognorm", "gamma"]
    dist_results = []
    params = {}

    for dist_name in dist_names:
        dist = getattr(stats, dist_name)
        param = dist.fit(data)
        params[dist_name] = param
        D, p = stats.kstest(data, dist_name, args=param)
        dist_results.append((dist_name, p))

    poisson_param = np.mean(data)
    D, p = stats.kstest(data, 'poisson', args=(poisson_param,))
    dist_results.append(('poisson', p))
    params['poisson'] = (poisson_param,)

    best_dist, best_p = max(dist_results, key=lambda item: item[1])

    plt.figure(figsize=(12, 8))
    sns.histplot(data, bins=30, kde=False, color='blue', stat='density')

    if best_dist == 'poisson':
        best_param = params['poisson']
        x = np.arange(min(data), max(data) + 1)
        pmf = stats.poisson.pmf(x, *best_param)
        plt.plot(x, pmf, label=f'{best_dist}', color='red')
    else:
        best_dist = getattr(stats, best_dist)
        best_param = params[best_dist.name]
        pdf = best_dist.pdf(np.linspace(min(data), max(data), 100), *best_param[:-2], loc=best_param[-2], scale=best_param[-1])
        plt.plot(np.linspace(min(data), max(data), 100), pdf, label=f'{best_dist.name}', color='red')

    plt.title(f'{title}\nBest fit distribution: {best_dist}')
    plt.legend()
    plt.show()

    return best_dist.name, best_param

def process_file(file_path):
    df = load_data(file_path)
    G = create_graph(df)
    modularity = calculate_modularity(G)
    print("Modularity:", modularity)
    
    metrics, mean_metrics = calculate_metrics(G)
    for key, value in metrics.items():
        print(f"{key.capitalize()}: {value}")
    for key, value in mean_metrics.items():
        print(f"{key.capitalize()}: {value}")

    outdegree = np.array(list(metrics['outdegree'].values()))
    indegree = np.array(list(metrics['indegree'].values()))
    outstrength = np.array(list(metrics['outstrength'].values()))
    instrength = np.array(list(metrics['instrength'].values()))

    best_outdegree_dist, outdegree_params = fit_distribution(outdegree, "Out-Degree Distribution")
    best_indegree_dist, indegree_params = fit_distribution(indegree, "In-Degree Distribution")
    best_outstrength_dist, outstrength_params = fit_distribution(outstrength, "Out-Strength Distribution")
    best_instrength_dist, instrength_params = fit_distribution(instrength, "In-Strength Distribution")

    ranges = {
        'outdegree_range': (np.min(outdegree), np.max(outdegree)),
        'indegree_range': (np.min(indegree), np.max(indegree)),
        'outstrength_range': (np.min(outstrength), np.max(outstrength)),
        'instrength_range': (np.min(instrength), np.max(instrength))
    }

    print("Best fit distribution for Out-Degree:", best_outdegree_dist, outdegree_params)
    print("Best fit distribution for In-Degree:", best_indegree_dist, indegree_params)
    print("Best fit distribution for Out-Strength:", best_outstrength_dist, outstrength_params)
    print("Best fit distribution for In-Strength:", best_instrength_dist, instrength_params)
    for key, value in ranges.items():
        print(f"Range for {key.replace('_', ' ').capitalize()}: {value}")

#%%
# Process the files
process_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_7_pd.csv")
#%%
process_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_30_pd.csv")
#%%