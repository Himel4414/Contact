# -*- coding: utf-8 -*-
"""
Assigning and shorting HMM States for each location
"""
#%%
import pandas as pd
import glob
import os
#%%
# Define paths  
paths = [  
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d1/",  
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d2/",  
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d3/",  
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d4/"  
]  
#%%
# Load HMM data
hmm_data = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/pig_data/pig_data_hmm.csv')
hmm_data['id'] = hmm_data['id'].astype(int)
# Add a new column 'state' based on the 'states' column
hmm_data['state'] = hmm_data['states'].map({0: 'resting', 1: 'foraging', 2: 'moving'})

print(hmm_data)
#%%
# Count the occurrences of each state
state_counts = hmm_data['state'].value_counts()

# Print the counts
print(state_counts)
#%%
def process_and_save(path):
    all_files = [os.path.join(path, f) for f in os.listdir(path) if f.endswith('.csv')]
    combined_data = pd.concat((pd.read_csv(f) for f in all_files), ignore_index=True)

    # Ensure 'id1' and 'id2' are integers
    combined_data['id1'] = combined_data['id1'].astype(int)
    combined_data['id2'] = combined_data['id2'].astype(int)

    # Merge for id1 and datetime1
    combined_data = combined_data.merge(hmm_data[['id', 'time_s', 'state']], how='left', left_on=['id1', 'datetime1'], right_on=['id', 'time_s'])
    combined_data.rename(columns={'state': 'state1'}, inplace=True)
    combined_data.drop(columns=['id', 'time_s'], inplace=True)  # Drop unnecessary columns after merge
    
    # Merge for id2 and datetime2
    combined_data = combined_data.merge(hmm_data[['id', 'time_s', 'state']], how='left', left_on=['id2', 'datetime2'], right_on=['id', 'time_s'])
    combined_data.rename(columns={'state': 'state2'}, inplace=True)
    combined_data.drop(columns=['id', 'time_s'], inplace=True)  # Drop unnecessary columns after merge
    
    output_file = f'C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_raw{paths.index(path)+1}.csv'
    combined_data.to_csv(output_file, index=False)
    print(f"Folder {os.path.basename(path)} done and CSV written.")

#%%
# Process each folder
for path in paths:
    process_and_save(path)
#%%
df1 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_raw1.csv')
df2 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_raw2.csv')
df3 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_raw3.csv')
df4 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_raw4.csv')
#%%
# Count the occurrences of each state
state_counts = df1['state1'].value_counts()

# Print the counts
print(state_counts)
#%%
# Define the filtering function
def filter_relevant_contacts(df):
    # Filter based on state conditions
    filtered_df = df[
        ((df['state1'] == 'resting') & (df['state2'] == 'resting')) |
        ((df['state1'] == 'resting') & (df['state2'] == 'foraging')) |
        ((df['state1'] == 'foraging') & (df['state2'] == 'resting')) |
        ((df['state1'] == 'foraging') & (df['state2'] == 'foraging'))
    ].copy()
    
    # Create new columns 'status1' and 'status2'
    filtered_df.loc[:, 'status1'] = filtered_df.apply(lambda row: 'h1' if row['datetime1'] < row['datetime2'] else 'h2', axis=1)
    filtered_df.loc[:, 'status2'] = filtered_df.apply(lambda row: 'h2' if row['datetime1'] < row['datetime2'] else 'h1', axis=1)
    
    # Create the 'relevance' column
    def determine_relevance(row):
        if row['status1'] == 'h2' and row['state1'] in ['resting', 'foraging']:
            return 'yes'
        elif row['status2'] == 'h2' and row['state2'] in ['resting', 'foraging']:
            return 'yes'
        return 'no'
    
    filtered_df.loc[:, 'relevance'] = filtered_df.apply(determine_relevance, axis=1)
    
    return filtered_df
#%%
# Apply filtering to each dataframe
df1_con = filter_relevant_contacts(df1)
df2_con = filter_relevant_contacts(df2)
df3_con = filter_relevant_contacts(df3)
df4_con = filter_relevant_contacts(df4)
print(df1_con)
#%%
combined_df = pd.concat([df1_con, df2_con, df3_con, df4_con], ignore_index=True)
combined_df = combined_df[combined_df['relevance'] == 'yes']
print(combined_df)

# Save the combined DataFrame to a new CSV file
combined_df.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/hmm_contact.csv', index=False)
#%%
import numpy as np
import pandas as pd

hmm_contact = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/hmm_contact.csv')
#%%
# Function to process combined DataFrame with decay rate
def process_combined_data(data, time_limit, decay_rate):
    if data.empty:
        print("No data found.")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    # Ensure datetime columns are in a numeric format if they aren't already
    data['datetime1'] = pd.to_numeric(data['datetime1'], errors='coerce')
    data['datetime2'] = pd.to_numeric(data['datetime2'], errors='coerce')
    
    # Create 'from' and 'to' columns based on datetime comparison
    data.loc[:, 'from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data.loc[:, 'to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    # Calculate the absolute time difference
    data['diff'] = (data['datetime1'] - data['datetime2']).abs()
    
    if data.empty:
        print("No valid rows after filtering.")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    # Convert the time difference to days
    data.loc[:, 'timediff'] = data['diff'] / 86400  # Assuming datetime is in seconds  
    # Filter rows within the time limit
    data = data[data['timediff'] <= time_limit]
    
    if data.empty:
        print("No rows within time limit.")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    # Apply the decay rate to the weight calculation
    data.loc[:, 'weight'] = np.exp(-decay_rate * data['timediff']) 
    # Generate 'pair' identifier for 'from' and 'to'
    data.loc[:, 'pair'] = data.apply(lambda row: f"{row['from']}_{row['to']}", axis=1) 
    # Group by 'from' and 'to' to sum the weights
    result = data.groupby(['from', 'to']).agg({'weight': 'sum'}).reset_index()
    
    return result

#%%
time_limit = 7  # Set  time limit in days
decay_rate = 0.7 # Set  decay rate
# Process the combined DataFrame
ind7 = process_combined_data(hmm_contact, time_limit, decay_rate)
#%%
# Show result
print(ind7)
# Save result to a CSV if needed
ind7.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/ind7_days.csv', index=False)
#%%
time_limit = 30  # Set  time limit in days
decay_rate = 0.16 # Set  decay rate
# Process the combined DataFrame
ind30 = process_combined_data(hmm_contact, time_limit, decay_rate)
#%%
# Show result
print(ind30)
# Save result to a CSV if needed
ind30.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/ind30_days.csv', index=False)
#%%
# Function to calculate overlap based on datetime1 and datetime2
def calculate_overlap(data):
    # Ensure datetime columns are numeric (Unix timestamps, if not already)
    data['datetime1'] = pd.to_numeric(data['datetime1'], errors='coerce')
    data['datetime2'] = pd.to_numeric(data['datetime2'], errors='coerce')

    # Create 'from', 'to', and 'pair' columns
    data['from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data['to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    data['pair'] = data.apply(lambda row: f"{int(row['id1'])}_{int(row['id2'])}", axis=1)

    # Group by 'pair' and calculate min/max for datetime1 and datetime2
    overlap = data.groupby('pair').agg(
        min_datetime1=('datetime1', 'min'),
        max_datetime1=('datetime1', 'max'),
        min_datetime2=('datetime2', 'min'),
        max_datetime2=('datetime2', 'max')
    ).reset_index()

    # Calculate the overlap start and end
    overlap['overlap_start'] = overlap[['min_datetime1', 'min_datetime2']].max(axis=1)
    overlap['overlap_end'] = overlap[['max_datetime1', 'max_datetime2']].min(axis=1)
    
    # Calculate the absolute overlap (in seconds) and convert it to days
    overlap['overlap'] = (overlap['overlap_end'] - overlap['overlap_start']).abs()
    overlap['overlap_days'] = overlap['overlap'] / 86400  # Convert seconds to days
    
    # Return the relevant columns
    return overlap[['pair', 'overlap_days']]
#%%
# Example usage with the combined DataFrame
overlap = calculate_overlap(hmm_contact)
print(overlap)
#%%
overlap_rev = overlap.copy()
overlap_rev['pair'] = overlap_rev['pair'].apply(lambda x: '_'.join(x.split('_')[::-1]))

# Combine the original 'overlap' DataFrame with the revised 'overlap_rev'
combined_overlap = pd.concat([overlap, overlap_rev], ignore_index=True)
#%%
# Save the overlap result to a CSV if needed
combined_overlap.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/overlap.csv', index=False)
#%%
# Load indirect contact data
indir_7 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/ind7_days.csv')
indir_7['pair'] = indir_7.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)

indir_30 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/ind30_days.csv')
indir_30['pair'] = indir_30.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)
#%%
# Add overlap data
indir_7_pd = indir_7.merge(combined_overlap[['pair', 'overlap_days']], on='pair', how='left')
indir_30_pd = indir_30.merge(combined_overlap[['pair', 'overlap_days']], on='pair', how='left')

print(indir_30_pd)
#%%
# Calculate weight per day
indir_7_pd['wpd'] = indir_7_pd['weight'] / indir_7_pd['overlap_days']
indir_30_pd['wpd'] = indir_30_pd['weight'] / indir_30_pd['overlap_days']
#%%
# Save final datasets
indir_7_pd[['from', 'to', 'weight', 'wpd']].to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_7_pd.csv', index=False)
indir_30_pd[['from', 'to', 'weight', 'wpd']].to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/3_with_hmm/indir_data/indir_30_pd.csv", index=False)

#%%



























