
"""
Extract and weight with Visitation rate

"""
#%%
import geopandas as gpd
import pandas as pd
import numpy as np
from shapely.geometry import Point
import os
#%%
visit = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use.shp")
print(visit)
#%%
### Get the high use areas as a new column in the contact data
def process_csv_files(directory, shapefile_path, crs='EPSG:32617'):
    # Load and concatenate CSV files
    csv_files = [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith('.csv')]
    df = pd.concat((pd.read_csv(file) for file in csv_files), ignore_index=True)

    # Create GeoDataFrame from DataFrame
    gdf = gpd.GeoDataFrame(
        df,
        geometry=[Point(xy) for xy in zip(df.x, df.y)],
        crs='EPSG:32617'
    )

    # Load shapefile and filter points
    shp = gpd.read_file(shapefile_path)
    shp = shp.to_crs(epsg=32617)
    gdf['high_use'] = gdf.geometry.apply(lambda point: any(shp.intersects(point)))
    gdf['high_use'] = gdf['high_use'].astype(int)

    return gdf[gdf['high_use'] == 1]
#%%
shapefile_path = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/env/visit/stack/high_use.shp"
#%%
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d1/"
gdf1 = process_csv_files(directory, shapefile_path)
df1 = gdf1.drop(columns='geometry')
df1.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/indir_raw_1.csv', index=False)
print(df1)
#%%
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d2/"
gdf2 = process_csv_files(directory, shapefile_path)
df2 = gdf2.drop(columns='geometry')
df2.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/indir_raw_2.csv', index=False)
print(df2)
#%%
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d3/"
gdf3 = process_csv_files(directory, shapefile_path)
df3 = gdf3.drop(columns='geometry')
df3.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/indir_raw_3.csv', index=False)
print(df3)
#%%
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d4/"
gdf4 = process_csv_files(directory, shapefile_path)
df4 = gdf4.drop(columns='geometry')
df4.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/indir_raw_4.csv', index=False)
print(df4)
#%%

# Function to process a list of DataFrames
def process_dataframes(dataframes, time_limit, decay_rate):
    # Concatenate all the DataFrames in the list
    data = pd.concat(dataframes, ignore_index=True)
    
    # Check if the concatenated DataFrame is empty
    if data.empty:
        print("No data found in the provided DataFrames.")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    # Determine 'from' and 'to' based on datetime comparison
    data['from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data['to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    
    # Calculate time difference in seconds and convert to days
    data['diff'] = (data['datetime1'] - data['datetime2']).abs()
    data['timediff'] = data['diff'] / 86400
    
    # Filter data based on the provided time limit
    data = data[data['timediff'] <= time_limit]
    if data.empty:
        print("No rows within time limit in the provided DataFrames.")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    # Calculate weights using an exponential decay based on 'timediff'
    data['weight'] = np.exp(-decay_rate * data['timediff'])    
    # Group by 'from', 'to' and sum the weights
    result = data.groupby(['from', 'to'], as_index=False).agg({'weight': 'sum'})
    
    return result
#%%
con_7 = process_dataframes([df1, df2, df3, df4], time_limit=7, decay_rate=0.7)
con_7['pair'] = con_7.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)
print(con_7)
#%%
con_30 = process_dataframes([df1, df2, df3, df4], time_limit=30, decay_rate=0.16)
con_30['pair'] = con_30.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)
print(con_30)
#%%
con_7.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/indir_7days_hu.csv", index=False)
con_30.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/indir_30days_hu.csv", index=False)
#%%
df1 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/indir_raw_1.csv')
df2 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/indir_raw_2.csv')
df3 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/indir_raw_3.csv')
df4 = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/indir_raw_4.csv')
#%%
# Function to calculate overlap
def calculate_overlap(data):
    data['from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data['to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    data['pair'] = data.apply(lambda row: f"{int(row['id1'])}_{int(row['id2'])}", axis=1)
    
    overlap = data.groupby('pair').agg(
        min_datetime1=('datetime1', 'min'),
        max_datetime1=('datetime1', 'max'),
        min_datetime2=('datetime2', 'min'),
        max_datetime2=('datetime2', 'max')
    ).reset_index()
    
    overlap['overlap_start'] = overlap[['min_datetime1', 'min_datetime2']].max(axis=1)
    overlap['overlap_end'] = overlap[['max_datetime1', 'max_datetime2']].min(axis=1)
    overlap['overlap'] = (overlap['overlap_end'] - overlap['overlap_start']).abs()
    overlap['overlap_days'] = overlap['overlap'] / 86400
    return overlap[['pair', 'overlap_days']]

# Function to load and process overlap data
def load_and_calculate_overlap(dfs):
    data = pd.concat(dfs, ignore_index=True)
    return calculate_overlap(data)
#%%
# Calculate overlap
overlap = load_and_calculate_overlap([df1, df2, df3, df4])
print(overlap)

#%%
reversed_overlap = overlap.copy()
reversed_overlap['pair'] = overlap['pair'].apply(lambda x: '_'.join(x.split('_')[::-1]))
overlap = pd.concat([overlap, reversed_overlap], ignore_index=True)
#%%
overlap.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/overlap.csv", index=False)
print(overlap)
#%%
# Load indirect contact data
indir_7 = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/indir_7days_hu.csv")
indir_30 = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/indir_30days_hu.csv")
#%%
# Add overlap data
indir_7_pd_hu = indir_7.merge(overlap[['pair', 'overlap_days']], on='pair', how='left')
indir_30_pd_hu = indir_30.merge(overlap[['pair', 'overlap_days']], on='pair', how='left')
print(indir_30_pd_hu)
#%%
# Calculate weight per day
indir_7_pd_hu['wpd'] = indir_7_pd_hu['weight'] / indir_7_pd_hu['overlap_days']
indir_30_pd_hu['wpd'] = indir_30_pd_hu['weight'] / indir_30_pd_hu['overlap_days']
#%%
# Save final datasets
indir_7_pd_hu[['from', 'to', 'weight', 'wpd']].to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/indir_7days_pd_hu.csv", index=False)
indir_30_pd_hu[['from', 'to', 'weight', 'wpd']].to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/contact/indir_30days_pd_hu.csv", index=False)
#%%