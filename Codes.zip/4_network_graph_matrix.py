
"""
Network graph and Matrices
"""
#%%1
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import numpy as np
import panel as pn
#%%2
indir1_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_7_pd.csv")
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_30_pd.csv")
print(indir1_df)
#%%3
indir1_df = indir1_df.iloc[:,[0,1,3]]
indir2_df = indir2_df.iloc[:,[0,1,3]]
indir1_df.columns = ["id1", "id2", "weight"]
indir2_df.columns = ["id1", "id2", "weight"]
indir1_df['id1'] = indir1_df['id1'].astype(str)
indir1_df['id2'] = indir1_df['id2'].astype(str)
indir2_df['id1'] = indir2_df['id1'].astype(str)
indir2_df['id2'] = indir2_df['id2'].astype(str)
#%%4
g_indirect7 = nx.from_pandas_edgelist(indir1_df, source='id1', target='id2', edge_attr='weight', create_using=nx.DiGraph())
g_indirect30 = nx.from_pandas_edgelist(indir2_df, source='id1', target='id2', edge_attr='weight', create_using=nx.DiGraph())
#%%5
# Get all unique nodes
all_nodes = (set(g_indirect7.nodes())).union(set(g_indirect30.nodes()))
g_indirect7.add_nodes_from(all_nodes - set(g_indirect7.nodes()))
g_indirect30.add_nodes_from(all_nodes - set(g_indirect30.nodes()))
#%%6
# Adjust weights
for g in [ g_indirect7, g_indirect30]:
    for u, v, d in g.edges(data=True):
        d['weight'] = np.log(d['weight'] + 1)
#%%7
# Read the sex information
sex = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/OriginalData/sex_pig.csv")
sex['id'] = sex['id'].astype(str)
sex_dict = dict(zip(sex['id'], sex['sex']))
#%%8
# Assign sex information to nodes
for g in [ g_indirect7, g_indirect30]:
    for node in g.nodes():
        g.nodes[node]['sex'] = sex_dict.get(node, 'F')
#%%9
# Function to get node colors
vertex_colors = {"M": "lightgreen", "F": "pink"}
def get_node_colors(g):
    return [vertex_colors[g.nodes[n]['sex']] for n in g.nodes]
#%%10
import pickle

# Load the layout from the file
with open('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/layout_all.pkl', 'rb') as f:
    layout_all = pickle.load(f)
    
#%%11
# Define common parameters
vertex_size = 1000
vertex_label_fontsize = 14
edge_color = "darkgrey"
    
#%%12
 # Plot Indirect Contacts with 7 days Pathogen Decay
plt.figure(figsize=(12, 12))
nx.draw(g_indirect7, pos=layout_all, with_labels=True, node_color=get_node_colors(g_indirect7), 
            node_size=vertex_size, edge_color=edge_color, font_size=vertex_label_fontsize,
           width=[np.log(d['weight'])*0.3 for u, v, d in g_indirect7.edges(data=True)],
            arrowsize=20, connectionstyle='arc3,rad=0.2')
plt.title("Indirect Contacts with Pathogen Decay (7 days)")
    # Add the legend
male_legend = mlines.Line2D([], [], color='lightgreen', marker='o', linestyle='None', markersize=12, label='Male')
female_legend = mlines.Line2D([], [], color='pink', marker='o', linestyle='None', markersize=12, label='Female')
plt.legend(handles=[male_legend, female_legend], loc='best', title='Sex')

plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/indir7_net_hmm.jpg', 
                dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()

#%%13
    # Plot Indirect Contacts with 30 days Pathogen Decay
plt.figure(figsize=(12, 12))
nx.draw(g_indirect30, pos=layout_all, with_labels=True, node_color=get_node_colors(g_indirect30), 
            node_size=vertex_size, edge_color=edge_color, font_size=vertex_label_fontsize,
            width=[np.log(d['weight'])*0.5 for u, v, d in g_indirect30.edges(data=True)],
            arrowsize=20, connectionstyle='arc3,rad=0.2')
plt.title("Indirect Contacts with Pathogen Decay (30 days)")
    # Add the legend
male_legend = mlines.Line2D([], [], color='lightgreen', marker='o', linestyle='None', markersize=12, label='Male')
female_legend = mlines.Line2D([], [], color='pink', marker='o', linestyle='None', markersize=12, label='Female')
plt.legend(handles=[male_legend, female_legend], loc='best', title='Sex')

plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/indir30_net_hmm.jpg', 
                dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()

#%%14

"""
Network_Matrix
"""

#%%15
import networkx as nx
import pandas as pd
import numpy as np
from scipy import stats
import seaborn as sns
import community.community_louvain as community_louvain
import matplotlib.pyplot as plt
#%%16
def process_graph(indir_df, title):
    # Process the dataframe to extract necessary columns
    indir_df = indir_df.iloc[:, [0, 1, 3]]
    indir_df.columns = ["id1", "id2", "weight"]

    # Create a directed graph
    G = nx.DiGraph()
    
    # Add weighted edges to the graph
    for idx, row in indir_df.iterrows():
        G.add_edge(row['id1'], row['id2'], weight=row['weight'])
    
    # Modularity (using Louvain community detection)
    partition = community_louvain.best_partition(nx.Graph(G))  # Treat as undirected for community detection
    modularity = community_louvain.modularity(partition, nx.Graph(G))
    print(f"Modularity ({title}):", modularity)

    # Calculate network metrics
    transitivity = nx.transitivity(G)
    edge_density = nx.density(G)
    assortativity = nx.degree_pearson_correlation_coefficient(G)
    outdegree = dict(G.out_degree())
    indegree = dict(G.in_degree())
    outstrength = dict(G.out_degree(weight='weight'))
    instrength = dict(G.in_degree(weight='weight'))
    closeness = nx.closeness_centrality(G)
    betweenness = nx.betweenness_centrality(G, weight='weight')

    # Print key metrics
    print(f"Transitivity ({title}):", transitivity)
    mean_close = sum(closeness.values()) / len(closeness)
    print(f"Mean Closeness ({title}):", mean_close)
    
    # Eigenvector centrality calculation
    try:
        eigenvector = nx.eigenvector_centrality(G, max_iter=10000, tol=1e-06, weight='weight')
        mean_eigenvector = sum(eigenvector.values()) / len(eigenvector)
        print(f"Mean Eigenvector Centrality ({title}):", mean_eigenvector)
        print(f"Eigenvector Centrality ({title}):", eigenvector)  # Print the actual eigenvector values
    except nx.PowerIterationFailedConvergence:
        print(f"Eigenvector centrality did not converge for {title}.")
        eigenvector = None

    mean_bet = sum(betweenness.values()) / len(betweenness)
    print(f"Mean Betweenness ({title}):", mean_bet)
    print(f"Edge Density ({title}):", edge_density)
    print(f"Assortativity ({title}):", assortativity)

    # Degree and strength metrics as numpy arrays
    outdegree_vals = np.array(list(outdegree.values()))
    indegree_vals = np.array(list(indegree.values()))
    outstrength_vals = np.array(list(outstrength.values()))
    instrength_vals = np.array(list(instrength.values()))

    # Fit distributions
    def fit_distribution(data, metric_title):
        dist_names = ["norm", "expon", "lognorm", "gamma"]
        dist_results = []
        params = {}

        for dist_name in dist_names:
            dist = getattr(stats, dist_name)
            param = dist.fit(data)
            params[dist_name] = param
            # Perform the Kolmogorov-Smirnov test
            D, p = stats.kstest(data, dist_name, args=param)
            dist_results.append((dist_name, p))

        # Special case for Poisson distribution
        poisson_param = np.mean(data)
        D, p = stats.kstest(data, 'poisson', args=(poisson_param,))
        dist_results.append(('poisson', p))
        params['poisson'] = (poisson_param,)

        # Select the best fitted distribution
        best_dist, best_p = max(dist_results, key=lambda item: item[1])

        # Plot the histogram and the best fit distribution
        #plt.figure(figsize=(12, 8))
        #sns.histplot(data, bins=30, kde=False, color='blue', stat='density')

        if best_dist == 'poisson':
            best_param = params['poisson']
            x = np.arange(min(data), max(data) + 1)
            pmf = stats.poisson.pmf(x, *best_param)
            plt.plot(x, pmf, label=f'{best_dist}', color='red')
        else:
            best_dist_obj = getattr(stats, best_dist)
            best_param = params[best_dist]
            pdf = best_dist_obj.pdf(np.linspace(min(data), max(data), 100), *best_param[:-2], loc=best_param[-2], scale=best_param[-1])
           # plt.plot(np.linspace(min(data), max(data), 100), pdf, label=f'{best_dist}', color='red')

        #plt.title(f'{metric_title}\nBest fit distribution: {best_dist}')
       # plt.legend()
       # plt.show()

        return best_dist, params.get(best_dist, None)

    # Fit and plot distributions for each metric
    best_outdegree_dist, outdegree_params = fit_distribution(outdegree_vals, f"Out-Degree Distribution ({title})")
    best_indegree_dist, indegree_params = fit_distribution(indegree_vals, f"In-Degree Distribution ({title})")
    best_outstrength_dist, outstrength_params = fit_distribution(outstrength_vals, f"Out-Strength Distribution ({title})")
    best_instrength_dist, instrength_params = fit_distribution(instrength_vals, f"In-Strength Distribution ({title})")

    # Calculate ranges
    outdegree_range = (np.min(outdegree_vals), np.max(outdegree_vals))
    indegree_range = (np.min(indegree_vals), np.max(indegree_vals))
    outstrength_range = (np.min(outstrength_vals), np.max(outstrength_vals))
    instrength_range = (np.min(instrength_vals), np.max(instrength_vals))

    # Display the results
    print(f"Best fit distribution for Out-Degree ({title}):", best_outdegree_dist, outdegree_params)
    print(f"Best fit distribution for In-Degree ({title}):", best_indegree_dist, indegree_params)
    print(f"Best fit distribution for Out-Strength ({title}):", best_outstrength_dist, outstrength_params)
    print(f"Best fit distribution for In-Strength ({title}):", best_instrength_dist, instrength_params)
    print(f"Range for Out-Degree ({title}):", outdegree_range)
    print(f"Range for In-Degree ({title}):", indegree_range)
    print(f"Range for Out-Strength ({title}):", outstrength_range)
    print(f"Range for In-Strength ({title}):", instrength_range)

#%%17
indir1_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_7_pd.csv")
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/indir_30_pd.csv")
#%%18
# Process the graphs for both datasets
process_graph(indir1_df, "7 Days Pathogen Decay")
#%%19
process_graph(indir2_df, "30 Days Pathogen Decay")
#%%
