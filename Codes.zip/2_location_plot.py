# -*- coding: utf-8 -*-
"""
Created on Sun Aug 18 21:17:40 2024

@author: himel
"""
# %%
import os
from functools import reduce
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from shapely.geometry import Point
from tqdm import tqdm
import numpy as np
# %% 

######################### Forr indirect contact 7 days PD + HU

# Directory where the CSV files are stored
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/"
# Get all CSV files in the directory
files = [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith(".csv")]

# %%
# Initialize an empty list to store DataFrames
dfs = []

# Loop through each file and read it into a DataFrame
for file in files:
    df = pd.read_csv(file)
    dfs.append(df)

# Combine all DataFrames into one by row-binding them
df = pd.concat(dfs, ignore_index=True)
print(df)
# %%
df['datetime1'] = df['datetime1'].astype(int)
df['datetime2'] = df['datetime2'].astype(int)
df['diff'] = abs(df['datetime1'] - df['datetime2'])
df['timediff'] = df['diff'] / 86400
df = df[df['timediff'] <= 7].copy()
df['weight'] = np.exp(-0.7 * df['timediff'])
print(df)
# %%
points_data = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.x, df.y))
print(points_data)

# %%
# Load your vector data (assuming it's a GeoDataFrame with polygons)
vector_data = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/contact_net/shp_base/shape_bg.shp")
# Add a count column to the vector data for indirect contact
vector_data['indirect_c'] = 0.0

# %%
# Split vector_data into 4 chunks manually
chunk_size = len(vector_data) // 4
chunks = [vector_data.iloc[i:i + chunk_size] for i in range(0, len(vector_data), chunk_size)]

# %%
# Ensure all data is covered, adjusting the last chunk if needed
if len(chunks) > 4:
    chunks[3] = pd.concat([chunks[3], chunks[4]])
    chunks = chunks[:4]
# %%
# Specify the directory where you want to save the chunks
output_directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/"

# Ensure the directory exists
os.makedirs(output_directory, exist_ok=True)

# %%
# Function to process each chunk
def process_chunk(chunk, points_data, chunk_idx):
    chunk = chunk.copy()
    for i, row in tqdm(chunk.iterrows(), total=chunk.shape[0], desc=f"Processing chunk {chunk_idx + 1}"):
        points_in_polygon = points_data[points_data.geometry.within(row.geometry)]
        if not points_in_polygon.empty:
            chunk.at[i, 'indirect_c'] = points_in_polygon['weight'].sum()
        else:
            chunk.at[i, 'indirect_c'] = 0.0

    # Save each chunk as a shapefile in the specified directory
    output_path = os.path.join(output_directory, f"chunk_{chunk_idx + 1}_hu1.shp")
    chunk.to_file(output_path)
    return chunk

# %%
# Process each chunk separately and save the results
results = []
for idx in range(0, 4):  # Start from index 2 for chunk 3 (index 0 is chunk 1, index 1 is chunk 2)
    chunk = chunks[idx]
    processed_chunk = process_chunk(chunk, points_data, idx)
    results.append(processed_chunk)

# %%
c1 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp7/chunk_1_hu1.shp")
c2 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp7/chunk_2_hu1.shp")
c3 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp7/chunk_3_hu1.shp")
c4 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp7/chunk_4_hu1.shp")
# %%
indir_7 = pd.concat([c1, c2, c3, c4], ignore_index=True)
print(indir_7)

# %%
# Save the merged result as a shapefile
indir7_gdf = gpd.GeoDataFrame(indir_7, geometry=indir_7.geometry)
#final_result_gdf.to_file("final_result.shp")

# %%
# Subset the data where Join_Count is not equal to 0
indir7_subset = indir7_gdf[indir7_gdf['points'] != 0].copy()
print(indir7_subset)
# %%
maxc= indir7_subset['indirect_c'].max()
print(maxc)
# %%
# Define bins and labels for categorical plotting
# Define bins and labels for categorical plotting
bins = [0, 10000, 35000, 65000, 135000, 250000, 350000, 391366]
labels = labels = ['0', '10000', '35000', '655000',  '135000', '250000', '350000']

# Create a new column 'category' for binning
indir7_subset['category'] = pd.cut(indir7_subset['indirect_c'], bins=bins, labels=labels, right=False)

# %%
fig, ax = plt.subplots(1, 1, figsize=(12, 12))

# Plot the polygons with count = 0 in grey
indir7_subset.plot(ax=ax, color='grey', edgecolor='none')

# Plot polygons with count > 0 using categorical colors
indir7_subset[indir7_subset['indirect_c'] > 0].plot(ax=ax, column='category', cmap='viridis', legend=False, edgecolor='none')

# Customize the legend
# Create a colormap for categorical data
cmap = mcolors.ListedColormap(plt.get_cmap('viridis').colors)
bounds = range(len(labels) + 1)
norm = mcolors.BoundaryNorm(bounds, cmap.N)

# Add colorbar with categorical ticks
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
cbar = fig.colorbar(sm, ax=ax, aspect=30, pad=0.02, shrink=0.5, ticks=range(len(labels)))
cbar.ax.set_yticklabels(labels)  # Set the tick labels to categorical labels
cbar.ax.tick_params(labelsize=8)
cbar.set_label('Indirect Contact', size=10)

# Customize the plot
ax.set_title('Indirect Contact')
ax.set_axis_off()

# Save the plot
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir7_location_plot_hu.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()
# %%


############################ For indirect contact 30 days PD + HU
    
# Directory where the CSV files are stored
directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir_data/"
# Get all CSV files in the directory
files = [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith(".csv")]

# %%
# Initialize an empty list to store DataFrames
dfs = []

# Loop through each file and read it into a DataFrame
for file in files:
    df = pd.read_csv(file)
    dfs.append(df)

# Combine all DataFrames into one by row-binding them
df = pd.concat(dfs, ignore_index=True)
print(df)
# %%

df['datetime1'] = df['datetime1'].astype(int)
df['datetime2'] = df['datetime2'].astype(int)
df['diff'] = abs(df['datetime1'] - df['datetime2'])
df['timediff'] = df['diff'] / 86400
df = df[df['timediff'] <= 30].copy()
df['weight'] = np.exp(-0.16 * df['timediff'])

# %%
# Combine all filtered dataframes into one
points_data = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.x, df.y))
print(points_data)
# %%
# Load your vector data (assuming it's a GeoDataFrame with polygons)
vector_data = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/contact_net/shp_base/shape_bg.shp")
# Add a count column to the vector data for indirect contact
vector_data['indirect_c'] = 0.0

# %%
# Split vector_data into 4 chunks manually
chunk_size = len(vector_data) // 4
chunks = [vector_data.iloc[i:i + chunk_size] for i in range(0, len(vector_data), chunk_size)]

# %%
# Ensure all data is covered, adjusting the last chunk if needed
if len(chunks) > 4:
    chunks[3] = pd.concat([chunks[3], chunks[4]])
    chunks = chunks[:4]
# %%
# Specify the directory where you want to save the chunks
output_directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp30/"

# Ensure the directory exists
os.makedirs(output_directory, exist_ok=True)

# %%
# Function to process each chunk
def process_chunk(chunk, points_data, chunk_idx):
    chunk = chunk.copy()
    for i, row in tqdm(chunk.iterrows(), total=chunk.shape[0], desc=f"Processing chunk {chunk_idx + 1}"):
        points_in_polygon = points_data[points_data.geometry.within(row.geometry)]
        if not points_in_polygon.empty:
            chunk.at[i, 'indirect_c'] = points_in_polygon['weight'].sum()
        else:
            chunk.at[i, 'indirect_c'] = 0.0

    # Save each chunk as a shapefile in the specified directory
    output_path = os.path.join(output_directory, f"chunk_{chunk_idx + 1}_hu2.shp")
    chunk.to_file(output_path)
    return chunk

# %%
# Process each chunk separately and save the results
results = []
for idx in range(2, 4):  # Start from index 2 for chunk 3 (index 0 is chunk 1, index 1 is chunk 2)
    chunk = chunks[idx]
    processed_chunk = process_chunk(chunk, points_data, idx)
    results.append(processed_chunk)

# %%
c1 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp30/chunk_1_hu2.shp")
c2 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp30/chunk_2_hu2.shp")
c3 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp30/chunk_3_hu2.shp")
c4 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/shp30/chunk_4_hu2.shp")
# %%
indir_30 = pd.concat([c1, c2, c3, c4], ignore_index=True)
print(indir_30)

# %%
# Save the merged result as a shapefile
indir30_gdf = gpd.GeoDataFrame(indir_30, geometry=indir_30.geometry)
#final_result_gdf.to_file("final_result.shp")

# %%
# Subset the data where Join_Count is not equal to 0
indir30_subset = indir_30[indir_30['points'] != 0].copy()
print(indir30_subset)
# %%
maxc= indir30_subset['indirect_c'].max()
print(maxc)
# %%
# Define bins and labels for categorical plotting
# Define bins and labels for categorical plotting
bins = [0, 10000, 35000, 65000, 135000, 250000, 350000, 391366]
labels = labels = ['0', '10000', '35000', '655000',  '135000', '250000', '350000']

# Create a new column 'category' for binning
indir30_subset['category'] = pd.cut(indir30_subset['indirect_c'], bins=bins, labels=labels, right=False)

# %%
fig, ax = plt.subplots(1, 1, figsize=(10, 10))

# Plot the polygons with count = 0 in grey
indir30_subset.plot(ax=ax, color='grey', edgecolor='none')

# Plot polygons with count > 0 using categorical colors
indir30_subset[indir30_subset['indirect_c'] > 0].plot(ax=ax, column='category', cmap='viridis', legend=False, edgecolor='none')

# Customize the legend
# Create a colormap for categorical data
cmap = mcolors.ListedColormap(plt.get_cmap('viridis').colors)
bounds = range(len(labels) + 1)
norm = mcolors.BoundaryNorm(bounds, cmap.N)

# Add colorbar with categorical ticks
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
cbar = fig.colorbar(sm, ax=ax, aspect=30, pad=0.02, shrink=0.5, ticks=range(len(labels)))
cbar.ax.set_yticklabels(labels)  # Set the tick labels to categorical labels
cbar.ax.tick_params(labelsize=8)
cbar.set_label('Indirect Contact', size=10)

# Customize the plot
ax.set_title('Indirect Contact')
ax.set_axis_off()

# Save the plot
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/2_with_high_use/indir30_location_plot_hu.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()
# %%    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

