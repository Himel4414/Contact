
"""
Extracting contact per pair
"""
#%%
import pandas as pd
import numpy as np
import os
from datetime import datetime
#%%
# Define paths
paths = [
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d1/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d2/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d3/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d4/"
]

#%%
# Function to process files in a given directory with decay rate
def process_directory(path, time_limit, decay_rate):
    csv_files = [os.path.join(path, f) for f in os.listdir(path) if f.endswith('.csv')]
    data = pd.concat([pd.read_csv(file) for file in csv_files], ignore_index=True)
    
    if data.empty:
        print(f"No data found in directory: {path}")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    data['from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data['to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    
    data['diff'] = (data['datetime1'] - data['datetime2']).abs()
    
    if data.empty:
        print(f"No valid rows after filtering in directory: {path}")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    data['timediff'] = data['diff'] / 86400
    data = data[data['timediff'] <= time_limit]
    
    if data.empty:
        print(f"No rows within time limit in directory: {path}")
        return pd.DataFrame(columns=['from', 'to', 'weight'])
    
    # Apply the decay rate to the weight calculation
    data['weight'] = np.exp(-decay_rate * data['timediff'])
    data['pair'] = data.apply(lambda row: f"{row['from']}_{row['to']}", axis=1)
    
    result = data.groupby(['from', 'to']).agg({'weight': 'sum'}).reset_index()
    return result
#%%
# Process directories for 7 days
d1_7 = process_directory(paths[0], time_limit=7, decay_rate=0.7)
d2_7 = process_directory(paths[1], time_limit=7, decay_rate=0.7)
d3_7 = process_directory(paths[2], time_limit=7, decay_rate=0.7)
d4_7 = process_directory(paths[3], time_limit=7, decay_rate=0.7)
#%%
# Combine and save for 7 days
indir_7days = pd.concat([d1_7, d2_7, d3_7, d4_7], ignore_index=True)
print(indir_7days)
#%%
indir_7days.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_7days.csv", index=False)
#%%

# Process directories for 30 days
d1_30 = process_directory(paths[0], time_limit=30, decay_rate=0.16)
d2_30 = process_directory(paths[1], time_limit=30, decay_rate=0.16)
d3_30 = process_directory(paths[2], time_limit=30, decay_rate=0.16)
d4_30 = process_directory(paths[3], time_limit=30, decay_rate=0.16)

#%%
# Combine and save for 30 days
indir_30days = pd.concat([d1_30, d2_30, d3_30, d4_30], ignore_index=True)
print(indir_30days)
#%%
indir_30days.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_30days.csv", index=False)
#%%
"""
Overlap days and weighting (cpd)
"""
#%%
# Function to calculate overlap
def calculate_overlap(data):
    data['from'] = np.where(data['datetime1'] <= data['datetime2'], data['id1'], data['id2'])
    data['to'] = np.where(data['datetime1'] <= data['datetime2'], data['id2'], data['id1'])
    data['pair'] = data.apply(lambda row: f"{int(row['id1'])}_{int(row['id2'])}", axis=1)
    
    overlap = data.groupby('pair').agg(
        min_datetime1=('datetime1', 'min'),
        max_datetime1=('datetime1', 'max'),
        min_datetime2=('datetime2', 'min'),
        max_datetime2=('datetime2', 'max')
).reset_index()
    
    overlap['overlap_start'] = overlap[['min_datetime1', 'min_datetime2']].max(axis=1)
    overlap['overlap_end'] = overlap[['max_datetime1', 'max_datetime2']].min(axis=1)
    overlap['overlap'] = (overlap['overlap_end'] - overlap['overlap_start']).abs()
    overlap['overlap_days'] = overlap['overlap'] / 86400
    return overlap[['pair', 'overlap_days']]

# Function to load and process overlap data
def load_and_calculate_overlap(path):
    csv_files = [os.path.join(path, f) for f in os.listdir(path) if f.endswith('.csv')]
    data = pd.concat([pd.read_csv(file) for file in csv_files], ignore_index=True)
    return calculate_overlap(data)

#%%
# Calculate overlap for each directory
overlap1 = load_and_calculate_overlap(paths[0])
overlap2 = load_and_calculate_overlap(paths[1])
overlap3 = load_and_calculate_overlap(paths[2])
overlap4 = load_and_calculate_overlap(paths[3])
#%%
# Combine overlaps
overlap = pd.concat([overlap1, overlap2, overlap3, overlap4], ignore_index=True)
print(overlap)
#%%
overlap_rev = overlap.copy()
overlap_rev['pair'] = overlap_rev['pair'].apply(lambda x: '_'.join(x.split('_')[::-1]))

# Combine the original 'overlap' DataFrame with the revised 'overlap_rev'
combined_overlap = pd.concat([overlap, overlap_rev], ignore_index=True)
combined_overlap.to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/overlap.csv", index=False)
print(combined_overlap)
#%%
# Load indirect contact data
indir_7 = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_7days.csv")
indir_7['pair'] = indir_7.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)

indir_30 = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_30days.csv")
indir_30['pair'] = indir_30.apply(lambda row: f"{int(row['from'])}_{int(row['to'])}", axis=1)

#%%
# Add overlap data
indir_7_pd = indir_7.merge(combined_overlap[['pair', 'overlap_days']], on='pair', how='left')
indir_30_pd = indir_30.merge(combined_overlap[['pair', 'overlap_days']], on='pair', how='left')

print(indir_30_pd)
#%%
# Calculate weight per day
indir_7_pd['wpd'] = indir_7_pd['weight'] / indir_7_pd['overlap_days']
indir_30_pd['wpd'] = indir_30_pd['weight'] / indir_30_pd['overlap_days']
#%%
# Save final datasets
indir_7_pd[['from', 'to', 'weight', 'wpd']].to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_7_pd.csv", index=False)
indir_30_pd[['from', 'to', 'weight', 'wpd']].to_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_30_pd.csv", index=False)

#%%





































