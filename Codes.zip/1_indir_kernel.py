
"""
Indirect kernel- 7 days

"""
#%%
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
#%%
indir1_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_7_pd.csv")
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_30_pd.csv")
#%%
import jenkspy
data = indir2_df['wpd'].values
num_classes = 7 
breaks = jenkspy.jenks_breaks(data, n_classes=num_classes)
print("Natural breaks:", breaks)
#%%
maxc= indir1_df['wpd'].max()
print(maxc)
#%%
# Define the corrected categories based on the range with a max of 2076
bins = [0, 35,  100, 200, 350, 600, 1000, 1500, 2000, np.inf]
labels = [
    '1',  '30', '100', '200', '350', '600', 
    '1000', '1500', '2076'
]
#%%
# Categorize the weights
indir1_df['wpd_category'] = pd.cut(indir1_df['wpd'], bins=bins, labels=labels, right=False)
# Get unique IDs
all_ids = np.unique(np.concatenate((indir1_df['from'], indir1_df['to'])))
#%%
# Create a matrix for the categorized weights
contact_matrix_categorical = np.full((len(all_ids), len(all_ids)), '', dtype=object)
for i, row in indir1_df.iterrows():
    id1, id2, category = row['from'], row['to'], row['wpd_category']
    contact_matrix_categorical[np.where(all_ids == id1)[0], np.where(all_ids == id2)[0]] = category

#%%
# Map the categories to numerical values for plotting
category_to_num = {label: i+1 for i, label in enumerate(labels)}
contact_matrix_numeric = np.vectorize(lambda x: category_to_num.get(x, 0))(contact_matrix_categorical)
# Convert the matrix to a DataFrame for easier plotting
contact_matrix_df = pd.DataFrame(contact_matrix_numeric, index=all_ids, columns=all_ids)
# Set zero values to NaN for displaying as white
contact_matrix_df = contact_matrix_df.replace(0, np.nan)
#%%
# Create a colormap for the bins
colors = sns.color_palette("OrRd", len(labels))
colors.insert(0, (1.0, 1.0, 1.0))  # Insert white at the beginning for NaN values
cmap = ListedColormap(colors)
norm = BoundaryNorm(boundaries=np.arange(len(labels)+2), ncolors=len(labels)+1)
#%%
# Calculate the figure size to make it square
fig_size = 10  # You can adjust this to make the entire figure larger or smaller

# Set the figure size and aspect ratio
plt.figure(figsize=(fig_size, fig_size))

# Create the heatmap with the custom colormap and square cells
sns.heatmap(contact_matrix_df, cmap=cmap, norm=norm, linewidths=0.05, linecolor='gray', square=True,
            cbar_kws={"orientation": "vertical", "pad": 0.1, "aspect": 20, "shrink": 0.5})

# Set the color bar labels
cbar = plt.gca().collections[0].colorbar
cbar.set_ticks(np.arange(1.5, len(labels)+1.5))
cbar.set_ticklabels(labels)
cbar.set_label('Contacts per Day')

# Plot diagonal line
plt.plot([0, len(all_ids)], [0, len(all_ids)], 'k--', lw=0.5)

# Set titles and labels
plt.title("Indirect Contact with 7 days pathogen decay")
plt.xlabel(" ")
plt.ylabel(" ")
plt.xticks(rotation=90)
plt.yticks(rotation=0)

# Save the plot as a JPG file with 1000x1000 dimensions
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/indir_7.jpg', dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')

# Display the plot
plt.show()
#%%
"""
Indirect kernel- 30 days

"""
#%%
indir2_df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/data/indir_30_pd.csv")
#%%
# Define the corrected categories based on the range with a max of 2076
bins = [0, 35,  100, 200, 350, 600, 1000, 1500, 2000, np.inf]
labels = [
    '1',  '30', '100', '200', '350', '600', 
    '1000', '1500', '2076'
]

#%%
# Categorize the weights for indir2
indir2_df['wpd_category'] = pd.cut(indir2_df['wpd'], bins=bins, labels=labels, right=False)
# Get unique IDs
all_ids = np.unique(np.concatenate((indir2_df['from'], indir2_df['to'])))

#%%
# Create a matrix for the categorized weights
contact_matrix_categorical = np.full((len(all_ids), len(all_ids)), '', dtype=object)
for i, row in indir2_df.iterrows():
    id1, id2, category = row['from'], row['to'], row['wpd_category']
    contact_matrix_categorical[np.where(all_ids == id1)[0], np.where(all_ids == id2)[0]] = category
#%%
# Map the categories to numerical values for plotting
category_to_num = {label: i+1 for i, label in enumerate(labels)}
contact_matrix_numeric = np.vectorize(lambda x: category_to_num.get(x, 0))(contact_matrix_categorical)
# Convert the matrix to a DataFrame for easier plotting
contact_matrix_df = pd.DataFrame(contact_matrix_numeric, index=all_ids, columns=all_ids)
# Set zero values to NaN for displaying as white
contact_matrix_df = contact_matrix_df.replace(0, np.nan)
#%%
# Create a colormap for the bins
colors = sns.color_palette("OrRd", len(labels))
colors.insert(0, (1.0, 1.0, 1.0))  # Insert white at the beginning for NaN values
cmap = ListedColormap(colors)
norm = BoundaryNorm(boundaries=np.arange(len(labels)+2), ncolors=len(labels)+1)
#%%
# Calculate the figure size to make it square
fig_size = 10  # You can adjust this to make the entire figure larger or smaller

# Set the figure size and aspect ratio
plt.figure(figsize=(fig_size, fig_size))

# Create the heatmap with the custom colormap and square cells
sns.heatmap(contact_matrix_df, cmap=cmap, norm=norm, linewidths=0.05, linecolor='gray', square=True,
            cbar_kws={"orientation": "vertical", "pad": 0.1, "aspect": 20, "shrink": 0.5})

# Set the color bar labels
cbar = plt.gca().collections[0].colorbar
cbar.set_ticks(np.arange(1.5, len(labels)+1.5))
cbar.set_ticklabels(labels)
cbar.set_label('Contacts per Day')

# Plot diagonal line
plt.plot([0, len(all_ids)], [0, len(all_ids)], 'k--', lw=0.5)

# Set titles and labels
plt.title("Indirect Contact with 30 days pathogen decay")
plt.xlabel(" ")
plt.ylabel(" ")
plt.xticks(rotation=90)
plt.yticks(rotation=0)

# Save the plot as a JPG file with 1000x1000 dimensions
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/indir_30.jpg', dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')

# Display the plot
plt.show()
#%%























