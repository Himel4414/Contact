
"""
Created on Tue Oct 29 11:52:42 2024

@author: himel
"""
# 7 days PD + HMM


# %%1
import os
from functools import reduce
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from shapely.geometry import Point
from tqdm import tqdm
import numpy as np
# %% 2
df = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/combined_high_use.csv')
#%%3
# Convert 'datetime1' and 'datetime2' to integer if they are not already in integer format
df['datetime1'] = df['datetime1'].astype(int)
df['datetime2'] = df['datetime2'].astype(int)

# Calculate time difference and filter data within 7 days
df['diff'] = abs(df['datetime1'] - df['datetime2'])
df['timediff'] = df['diff'] / 86400
df = df[df['timediff'] <= 7].copy()

# Apply weight calculation
df['weight'] = np.exp(-0.7 * df['timediff'])
print(df)
#%%4
# Convert DataFrame to GeoDataFrame
points_data = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.x, df.y))
# Print or further process points_data as needed
print(points_data)
# %%5
# Load your vector data (assuming it's a GeoDataFrame with polygons)
vector_data = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/contact_net/shp_base/shape_bg.shp")
# Add a count column to the vector data for indirect contact
vector_data['ind_c'] = 0.0

# %%6
# Split vector_data into 4 chunks manually
chunk_size = len(vector_data) // 4
chunks = [vector_data.iloc[i:i + chunk_size] for i in range(0, len(vector_data), chunk_size)]

# %%7
# Ensure all data is covered, adjusting the last chunk if needed
if len(chunks) > 4:
    chunks[3] = pd.concat([chunks[3], chunks[4]])
    chunks = chunks[:4]
# %%8
# Specify the directory where you want to save the chunks
output_directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp7/"

# Ensure the directory exists
os.makedirs(output_directory, exist_ok=True)

# %%9
# Function to process each chunk
def process_chunk(chunk, points_data, chunk_idx):
    chunk = chunk.copy()
    for i, row in tqdm(chunk.iterrows(), total=chunk.shape[0], desc=f"Processing chunk {chunk_idx + 1}"):
        points_in_polygon = points_data[points_data.geometry.within(row.geometry)]
        if not points_in_polygon.empty:
            chunk.at[i, 'ind_c'] = points_in_polygon['weight'].sum()
        else:
            chunk.at[i, 'ind_c'] = 0.0

    # Save each chunk as a shapefile in the specified directory
    output_path = os.path.join(output_directory, f"chunk_{chunk_idx + 1}_hmm7.shp")
    chunk.to_file(output_path)
    return chunk

# %%10
# Process each chunk separately and save the results
results = []
for idx in range(0, 4):  
    chunk = chunks[idx]
    processed_chunk = process_chunk(chunk, points_data, idx)
    results.append(processed_chunk)

# %%11
c1 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp7/chunk_1_hmm7.shp")
c2 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp7/chunk_2_hmm7.shp")
c3 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp7/chunk_3_hmm7.shp")
c4 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp7/chunk_4_hmm7.shp")
# %%12
indir_7 = pd.concat([c1, c2, c3, c4], ignore_index=True)
print(indir_7)

# %%13
# Save the merged result as a shapefile
indir7_gdf = gpd.GeoDataFrame(indir_7, geometry=indir_7.geometry)
indir7_gdf.to_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/shp_files/4_integ/indir_7.shp")

# %%14
# Subset the data where Join_Count is not equal to 0
indir7_subset = indir7_gdf[indir7_gdf['points'] != 0].copy()
print(indir7_subset)
# %%15
maxc= indir7_subset['ind_c'].max()
print(maxc)
# %%16
# Define bins and labels for categorical plotting
# Define bins and labels for categorical plotting
bins = [0, 10000, 35000, 65000, 135000, 250000, 350000, 391366]
labels = labels = ['0', '10000', '35000', '655000',  '135000', '250000', '350000']

# Create a new column 'category' for binning
indir7_subset['category'] = pd.cut(indir7_subset['ind_c'], bins=bins, labels=labels, right=False)

# %%17
fig, ax = plt.subplots(1, 1, figsize=(10, 10))

# Plot the polygons with count = 0 in grey
indir7_subset.plot(ax=ax, color='grey', edgecolor='none')

# Plot polygons with count > 0 using categorical colors
indir7_subset[indir7_subset['ind_c'] > 0].plot(ax=ax, column='category', cmap='viridis', legend=False, edgecolor='none')

# Customize the legend
# Create a colormap for categorical data
cmap = mcolors.ListedColormap(plt.get_cmap('viridis').colors)
bounds = range(len(labels) + 1)
norm = mcolors.BoundaryNorm(bounds, cmap.N)

# Add colorbar with categorical ticks
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
cbar = fig.colorbar(sm, ax=ax, aspect=30, pad=0.02, shrink=0.5, ticks=range(len(labels)))
cbar.ax.set_yticklabels(labels)  # Set the tick labels to categorical labels
cbar.ax.tick_params(labelsize=8)
cbar.set_label('Indirect Contact', size=10)

# Customize the plot
ax.set_title('Indirect Contact')
ax.set_axis_off()

# Save the plot
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/indir7_location_plot_hmm.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()
# %%18

# 30 days PD + HMM


# %%19
import os
from functools import reduce
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from shapely.geometry import Point
from tqdm import tqdm
import numpy as np
# %% 20
df = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/data/combined_high_use.csv')
#%%21
# Convert 'datetime1' and 'datetime2' to integer if they are not already in integer format
df['datetime1'] = df['datetime1'].astype(int)
df['datetime2'] = df['datetime2'].astype(int)

# Calculate time difference and filter data within 7 days
df['diff'] = abs(df['datetime1'] - df['datetime2'])
df['timediff'] = df['diff'] / 86400
df = df[df['timediff'] <= 30].copy()

# Apply weight calculation
df['weight'] = np.exp(-0.16 * df['timediff'])
print(df)
#%%22
# Convert DataFrame to GeoDataFrame
points_data = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df.x, df.y))
# Print or further process points_data as needed
print(points_data)
# %%23
# Load your vector data (assuming it's a GeoDataFrame with polygons)
vector_data = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/contact_net/shp_base/shape_bg.shp")
# Add a count column to the vector data for indirect contact
vector_data['ind_c'] = 0.0

# %%24
# Split vector_data into 4 chunks manually
chunk_size = len(vector_data) // 4
chunks = [vector_data.iloc[i:i + chunk_size] for i in range(0, len(vector_data), chunk_size)]

# %%25
# Ensure all data is covered, adjusting the last chunk if needed
if len(chunks) > 4:
    chunks[3] = pd.concat([chunks[3], chunks[4]])
    chunks = chunks[:4]
# %%26
# Specify the directory where you want to save the chunks
output_directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp30/"

# Ensure the directory exists
os.makedirs(output_directory, exist_ok=True)

# %%27
# Function to process each chunk
def process_chunk(chunk, points_data, chunk_idx):
    chunk = chunk.copy()
    for i, row in tqdm(chunk.iterrows(), total=chunk.shape[0], desc=f"Processing chunk {chunk_idx + 1}"):
        points_in_polygon = points_data[points_data.geometry.within(row.geometry)]
        if not points_in_polygon.empty:
            chunk.at[i, 'ind_c'] = points_in_polygon['weight'].sum()
        else:
            chunk.at[i, 'ind_c'] = 0.0

    # Save each chunk as a shapefile in the specified directory
    output_path = os.path.join(output_directory, f"chunk_{chunk_idx + 1}_hmm30.shp")
    chunk.to_file(output_path)
    return chunk

# %%28
# Process each chunk separately and save the results
results = []
for idx in range(1, 4):
    chunk = chunks[idx]
    processed_chunk = process_chunk(chunk, points_data, idx)
    results.append(processed_chunk)

# %%29
c1 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp30/chunk_1_hmm30.shp")
c2 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp30/chunk_2_hmm30.shp")
c3 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp30/chunk_3_hmm30.shp")
c4 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/shp30/chunk_4_hmm30.shp")
# %%30
indir_30 = pd.concat([c1, c2, c3, c4], ignore_index=True)
print(indir_30)

# %%31
# Save the merged result as a shapefile
indir30_gdf = gpd.GeoDataFrame(indir_30, geometry=indir_30.geometry)
indir30_gdf.to_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/shp_files/4_integ/indir_30.shp")
# %%32
# Subset the data where Join_Count is not equal to 0
indir30_subset = indir30_gdf[indir30_gdf['points'] != 0].copy()
print(indir30_subset)
# %%33
maxc= indir30_subset['ind_c'].max()
print(maxc)
# %%34
# Define bins and labels for categorical plotting
# Define bins and labels for categorical plotting
bins = [0, 10000, 35000, 65000, 135000, 250000, 350000, 391366]
labels = labels = ['0', '10000', '35000', '655000',  '135000', '250000', '350000']

# Create a new column 'category' for binning
indir30_subset['category'] = pd.cut(indir30_subset['ind_c'], bins=bins, labels=labels, right=False)

# %%35
fig, ax = plt.subplots(1, 1, figsize=(10, 10))

# Plot the polygons with count = 0 in grey
indir30_subset.plot(ax=ax, color='grey', edgecolor='none')

# Plot polygons with count > 0 using categorical colors
indir30_subset[indir30_subset['ind_c'] > 0].plot(ax=ax, column='category', cmap='viridis', legend=False, edgecolor='none')

# Customize the legend
# Create a colormap for categorical data
cmap = mcolors.ListedColormap(plt.get_cmap('viridis').colors)
bounds = range(len(labels) + 1)
norm = mcolors.BoundaryNorm(bounds, cmap.N)

# Add colorbar with categorical ticks
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
cbar = fig.colorbar(sm, ax=ax, aspect=30, pad=0.02, shrink=0.5, ticks=range(len(labels)))
cbar.ax.set_yticklabels(labels)  # Set the tick labels to categorical labels
cbar.ax.tick_params(labelsize=8)
cbar.set_label('Indirect Contact', size=10)

# Customize the plot
ax.set_title('Indirect Contact')
ax.set_axis_off()

# Save the plot
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/4_integ/indir30_location_plot_hmm.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()
# %%
