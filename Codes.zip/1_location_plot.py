
"""
Contact Location Plot- 7 days

"""
#%%
import geopandas as gpd
import pandas as pd
import matplotlib.pyplot as plt
from shapely.geometry import Point
import matplotlib.colors as mcolors
from tqdm import tqdm
import os
import numpy as np
#%%
# Define the directory paths
directories = [
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d1/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d2/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d3/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d4/"
]
#%%
dfs = []
for directory in directories:
    files = [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith(".csv")]
    df = pd.concat([pd.read_csv(file) for file in files])
    df['diff'] = abs(df['datetime1'] - df['datetime2'])
    df['timediff'] = df['diff'] / 86400
    df_filtered = df[df['timediff'] <= 7].copy()
    df_filtered['weight'] = np.exp(-0.7 * df_filtered['timediff'])
    dfs.append(df_filtered)

#%%
# Combine all filtered dataframes into one
points_data = pd.concat(dfs)
#%%
points_data = gpd.GeoDataFrame(points_data, geometry=gpd.points_from_xy(points_data.x, points_data.y))
print(points_data)
#%%
# Load your vector data (assuming it's a GeoDataFrame with polygons)
vector_data = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/contact_net/shp_base/shape_bg.shp")
# Add a count column to the vector data for indirect contact
vector_data['indirect_c'] = 0
#%%
# Split vector_data into 4 chunks manually
chunk_size = len(vector_data) // 4
chunks = [vector_data.iloc[i:i + chunk_size] for i in range(0, len(vector_data), chunk_size)]
#%%
# Ensure all data is covered, adjusting the last chunk if needed
if len(chunks) > 4:
    chunks[3] = pd.concat([chunks[3], chunks[4]])
    chunks = chunks[:4]

#%%
# Function to process each chunk
# Function to process each chunk
def process_chunk(chunk, points_data, chunk_idx, output_dir):
    chunk = chunk.copy()
    for i, row in tqdm(chunk.iterrows(), total=chunk.shape[0], desc=f"Processing chunk {chunk_idx + 1}"):
        points_in_polygon = points_data[points_data.geometry.within(row.geometry)]
        if not points_in_polygon.empty:
            chunk.at[i, 'indirect_c'] = points_in_polygon['weight'].sum()
        else:
            chunk.at[i, 'indirect_c'] = 0

    # Create the directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    # Save each chunk as a shapefile
    chunk.to_file(os.path.join(output_dir, f"chunk_{chunk_idx + 1}_ind2.shp"))
    return chunk
#%%
output_directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp7/"
# Process each chunk separately and save the results
results = []
for idx in range(0, 4):  # Start from index 2 for chunk 3 (index 0 is chunk 1, index 1 is chunk 2)
    chunk = chunks[idx]
    processed_chunk = process_chunk(chunk, points_data, idx)
    results.append(processed_chunk)
 #%%
c1 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp7/chunk_1_results.shp")
c2 = gpd.read_file('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp7/chunk_2_results.shp')
c3 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp7/chunk_3_results.shp")
c4 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp7/chunk_4_results.shp")
#%%
indir_7 = pd.concat([c1, c2, c3, c4], ignore_index=True)
print(indir_7)
#%%
# Save the merged result as a shapefile
indir7_gdf = gpd.GeoDataFrame(indir_7, geometry=indir_7.geometry)
# Subset the data where Join_Count is not equal to 0
indir7_subset = indir7_gdf[indir7_gdf['points'] != 0].copy()
print(indir7_gdf)
# %%
maxc= indir7_gdf['indirect_c'].max()
print(maxc)
#%%
# Define bins and labels for categorical plotting
bins = [0, 10000, 35000, 65000, 135000, 250000, 350000, 391366]
labels = labels = ['0', '10000', '35000', '655000',  '135000', '250000', '350000']

# Create a new column 'category' for binning
indir7_subset['category'] = pd.cut(indir7_subset['indirect_c'], bins=bins, labels=labels, include_lowest=True)
#%%
fig, ax = plt.subplots(1, 1, figsize=(12, 12))

# Plot the polygons with count = 0 in grey
indir7_subset.plot(ax=ax, color='grey', edgecolor='none')

# Plot polygons with count > 0 using categorical colors
indir7_subset[indir7_subset['indirect_c'] > 0].plot(ax=ax, column='category', cmap='viridis', legend=False, edgecolor='none')

# Customize the legend
# Create a colormap for categorical data
cmap = mcolors.ListedColormap(plt.get_cmap('viridis').colors)
bounds = range(len(labels) + 1)
norm = mcolors.BoundaryNorm(bounds, cmap.N)

# Add colorbar with categorical ticks
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
cbar = fig.colorbar(sm, ax=ax, aspect=30, pad=0.02, shrink=0.5, ticks=range(len(labels)))
cbar.ax.set_yticklabels(labels)  # Set the tick labels to categorical labels
cbar.ax.tick_params(labelsize=8)
cbar.set_label('Indirect Contact', size=10)

# Customize the plot
ax.set_title('Indirect Contact')
ax.set_axis_off()

# Save the plot
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/indir7_location_plot.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()
#%%

"""
Contact Location Plot- 30 days

"""

#%%
# Define the directory paths
directories = [
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d1/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d2/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d3/",
    "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/indirect_contact/d4/"
]
#%%
dfs = []
for directory in directories:
    files = [os.path.join(directory, file) for file in os.listdir(directory) if file.endswith(".csv")]
    df = pd.concat([pd.read_csv(file) for file in files])
    df['diff'] = abs(df['datetime1'] - df['datetime2'])
    df['timediff'] = df['diff'] / 86400
    df_filtered = df[df['timediff'] <= 30].copy()
    df_filtered['weight'] = np.exp(-0.16 * df_filtered['timediff'])
    dfs.append(df_filtered)
#%%
# Combine all filtered dataframes into one
points_data = pd.concat(dfs)
points_data = gpd.GeoDataFrame(points_data, geometry=gpd.points_from_xy(points_data.x, points_data.y))
#%%
# Load your vector data (assuming it's a GeoDataFrame with polygons)
vector_data = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/contact_net/shp_base/shape_bg.shp")
# Add a count column to the vector data for indirect contact
vector_data['indirect_c'] = 0
#%%
# Split vector_data into 4 chunks manually
chunk_size = len(vector_data) // 4
chunks = [vector_data.iloc[i:i + chunk_size] for i in range(0, len(vector_data), chunk_size)]
#%%
# Ensure all data is covered, adjusting the last chunk if needed
if len(chunks) > 4:
    chunks[3] = pd.concat([chunks[3], chunks[4]])
    chunks = chunks[:4]
#%%
# Function to process each chunk
# Function to process each chunk
def process_chunk(chunk, points_data, chunk_idx, output_dir):
    chunk = chunk.copy()
    for i, row in tqdm(chunk.iterrows(), total=chunk.shape[0], desc=f"Processing chunk {chunk_idx + 1}"):
        points_in_polygon = points_data[points_data.geometry.within(row.geometry)]
        if not points_in_polygon.empty:
            chunk.at[i, 'indirect_c'] = points_in_polygon['weight'].sum()
        else:
            chunk.at[i, 'indirect_c'] = 0

    # Create the directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    # Save each chunk as a shapefile
    chunk.to_file(os.path.join(output_dir, f"chunk_{chunk_idx + 1}_ind2.shp"))
    return chunk
#%%
output_directory = "C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp30/"
# Process each chunk separately and save the results
results = []
for idx in range(0, 4):  # Start from index 2 for chunk 3 (index 0 is chunk 1, index 1 is chunk 2)
    chunk = chunks[idx]
    processed_chunk = process_chunk(chunk, points_data, idx)
    results.append(processed_chunk)
#%%
c1 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp30/chunk_1_ind2.shp")
c2 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp30/chunk_2_ind2.shp")
c3 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp30/chunk_3_ind2.shp")
c4 = gpd.read_file("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/shp30/chunk_4_ind2.shp")
#%%
indir_30 = pd.concat([c1, c2, c3, c4], ignore_index=True)
print(indir_30)
#%%
# Save the merged result as a shapefile
indir30_gdf = gpd.GeoDataFrame(indir_30, geometry=indir_30.geometry)
# Subset the data where Join_Count is not equal to 0
indir30_subset = indir30_gdf[indir30_gdf['points'] != 0].copy()
print(indir30_subset)
# %%
maxc= indir30_gdf['indirect_c'].max()
print(maxc)
#%%
import jenkspy
data = indir30_gdf['indirect_c'].values
num_classes = 7 
breaks = jenkspy.jenks_breaks(data, n_classes=num_classes)
print("Natural breaks:", breaks)
#%%
# Define bins and labels for categorical plotting
bins = [0, 10000, 35000, 65000, 135000, 250000, 350000, 391366]
labels = labels = ['0', '10000', '35000', '655000',  '135000', '250000', '350000']

# Create a new column 'category' for binning
indir30_subset['category'] = pd.cut(indir30_subset['indirect_c'], bins=bins, labels=labels, right=False)
#%%
fig, ax = plt.subplots(1, 1, figsize=(12, 12))

# Plot the polygons with count = 0 in grey
indir30_subset.plot(ax=ax, color='grey', edgecolor='none')

# Plot polygons with count > 0 using categorical colors
indir30_subset[indir30_subset['indirect_c'] > 0].plot(ax=ax, column='category', cmap='viridis', legend=False, edgecolor='none')

# Customize the legend
# Create a colormap for categorical data
cmap = mcolors.ListedColormap(plt.get_cmap('viridis').colors)
bounds = range(len(labels) + 1)
norm = mcolors.BoundaryNorm(bounds, cmap.N)

# Add colorbar with categorical ticks
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
cbar = fig.colorbar(sm, ax=ax, aspect=30, pad=0.02, shrink=0.5, ticks=range(len(labels)))
cbar.ax.set_yticklabels(labels)  # Set the tick labels to categorical labels
cbar.ax.tick_params(labelsize=8)
cbar.set_label('Indirect Contact', size=10)

# Customize the plot
ax.set_title('Indirect Contact')
ax.set_axis_off()

# Save the plot
plt.savefig('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/py_con/1_with_pd_only/indir30_location_plot.jpg', 
            dpi=600, bbox_inches='tight', pad_inches=0.1, format='jpg')
plt.show()
#%%