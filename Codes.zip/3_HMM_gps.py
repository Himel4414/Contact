# -*- coding: utf-8 -*-
"""
Created on Fri Sep 13 19:30:42 2024

@author: himel
"""
#%%
import numpy as np
import pandas as pd
from hmmlearn.hmm import GaussianHMM
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
#%%
# Load and prepare data
dat = pd.read_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/pig_data/pig_data.csv')
dat['id'] = dat['id'].astype(int)
print(dat)

#%%
data = dat[['id','x', 'y','time_s']]
# Normalize timestamp (optional)
data['time_s'] = (data['time_s'] - data['time_s'].min()) / (data['time_s'].max() - data['time_s'].min())
scaler = StandardScaler()
data[['x', 'y', 'time_s']] = scaler.fit_transform(data[['x', 'y', 'time_s']])
#%% 
n_states = 3  # Start with fewer states
n_iter = 200  # Increase iterations for better convergence
# Create an empty DataFrame to store results
results = pd.DataFrame()
#%%
for pid, group in data.groupby('id'):
    # Extract 'x', 'y', and 'time_s' as features
    data_array = group[['x', 'y', 'time_s']].values

    # Initialize and fit the HMM model for each id
    model = GaussianHMM(n_components=n_states, covariance_type='full', n_iter=n_iter, random_state=42, tol=1e-3)
    
    try:
        model.fit(data_array)
        # Predict hidden states
        states = model.predict(data_array)
        group['states'] = states
        
    except ValueError as e:
        print(f"Model did not converge for id {pid}: {e}")
        continue
    
    # Append the results to the final DataFrame
    results = pd.concat([results, group])

print(results)
#%%
state_counts = results['states'].value_counts()

# Print the counts
print(state_counts)
#%%
dat['states'] = results['states'].values
print(dat)
#%%

# Save the updated data
dat.to_csv('C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/pig_data/pig_data_hmm.csv', index=False)
#%%
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde

# Load the HMM-annotated data
df = pd.read_csv("C:/Users/himel/OneDrive - University of Oklahoma/Ch2_Florida/Florida_data/pig_data/pig_data_hmm.csv")

# Drop missing values just in case
df = df.dropna(subset=['x', 'y', 'id', 'states'])

# Sort for consistent direction calculation
df = df.sort_values(by=['id', 'time_s'])

# Compute step direction and turning angle
def compute_turning_angles(group):
    dx = group['x'].diff()
    dy = group['y'].diff()
    directions = np.arctan2(dy, dx)
    turning_angles = (directions - directions.shift(1) + np.pi) % (2 * np.pi) - np.pi
    group['turning_angle'] = turning_angles
    return group

df = df.groupby('id').apply(compute_turning_angles).reset_index(drop=True)

# Drop NA values from turning angles
df = df.dropna(subset=['turning_angle', 'states'])

# Define color mapping and state labels
state_colors = {
    0: "#E69F00",  # orange
    1: "#56B4E9",  # blue
    2: "#009E73"   # green
}
state_labels = {
    0: "Resting",
    1: "Foraging",
    2: "Moving"
}

# Plot histogram
plt.figure(figsize=(10, 6))
plt.hist(df['turning_angle'], bins=20, density=True, color='lightgray', edgecolor='white', label='_nolegend_')

# Overlay KDE per state
angle_range = np.linspace(-np.pi, np.pi, 300)
for state, color in state_colors.items():
    angles = df[df['states'] == state]['turning_angle']
    if len(angles) > 1:
        kde = gaussian_kde(angles)
        plt.plot(angle_range, kde(angle_range), label=state_labels[state], color=color, lw=1.5)

# Overlay total KDE
total_kde = gaussian_kde(df['turning_angle'])
plt.plot(angle_range, total_kde(angle_range), 'k--', label='Total', lw=1.5)

# Formatting
plt.xlabel("Turning angle")
plt.ylabel("Density")
plt.xticks(ticks=[-np.pi, -np.pi/2, 0, np.pi/2, np.pi],
           labels=[r"$-\pi$", r"$-\pi/2$", "0", r"$\pi/2$", r"$\pi$"])
plt.legend()
plt.tight_layout()
plt.show()

#%%
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde

# Drop missing values just in case
df = df.dropna(subset=['x', 'y', 'id', 'states'])

# Sort values to compute step differences correctly
df = df.sort_values(by=['id', 'time_s'])

# Compute step lengths (Euclidean distance between points)
def compute_step_lengths(group):
    dx = group['x'].diff()
    dy = group['y'].diff()
    step_length = np.sqrt(dx**2 + dy**2)
    group['step_length'] = step_length
    return group

df = df.groupby('id').apply(compute_step_lengths).reset_index(drop=True)
df = df.dropna(subset=['step_length'])

# Define state colors
state_colors = {
    0: "#E69F00",  # orange
    1: "#56B4E9",  # blue
    2: "#009E73"   # green
}

# Plot histogram of step lengths in range 0-500
plt.figure(figsize=(10, 6))
bins = np.linspace(0, 300, 41)
plt.hist(df['step_length'], bins=bins, density=True, color='lightgray', edgecolor='white', label='_nolegend_')

# KDE overlays per state, restricted to 0–500
x_range = np.linspace(-1, 250, 300)
for state, color in state_colors.items():
    lengths = df[df['states'] == state]['step_length']
    if len(lengths) > 1:
        kde = gaussian_kde(lengths)
        plt.plot(x_range, kde(x_range), label=f'state {state + 1}', color=color, lw=1.5)

# Total KDE overlay
total_kde = gaussian_kde(df['step_length'])
plt.plot(x_range, total_kde(x_range), 'k--', label='total', lw=1.5)

# Formatting
plt.xlabel("step length")
plt.ylabel("Density")
plt.xlim(0, 250)
plt.legend()
plt.tight_layout()
plt.show()


#%%
import numpy as np
import pandas as pd
from hmmlearn.hmm import GaussianHMM

# Your setup:
n_states = 3
n_iter = 200

# Prepare a list to store matrices
transition_matrices = []

# Fit one model per pig and store transition matrix
for pid, group in data.groupby('id'):
    X = group[['x', 'y', 'time_s']].values
    model = GaussianHMM(n_components=n_states, covariance_type='full', n_iter=n_iter, random_state=42)
    try:
        model.fit(X)
        transition_matrices.append(model.transmat_)
    except Exception as e:
        print(f"ID {pid} failed: {e}")

# Average across all pigs
mean_matrix = np.mean(transition_matrices, axis=0)

# Create a DataFrame for easy viewing
state_labels = ['Resting', 'Foraging', 'Moving']  # Adjust if your mapping differs
transition_df = pd.DataFrame(mean_matrix, index=state_labels, columns=state_labels)

# Print final transition matrix
print("Averaged HMM Transition Probability Matrix:\n")
print(transition_df.round(2))
